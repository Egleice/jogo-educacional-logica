/**
 * Simulated authentication service.
 * Each function mirrors a future REST endpoint — swap the body for a fetch() call:
 *   POST /api/auth/register, POST /api/auth/login, POST /api/auth/recover
 */
import type { User } from "@/lib/game/types";

const ACCOUNTS_KEY = "codigma:accounts";
const delay = (ms = 350) => new Promise((r) => setTimeout(r, ms));

interface StoredAccount extends User {
  password: string;
}

function readAccounts(): StoredAccount[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(ACCOUNTS_KEY) || "[]");
  } catch {
    return [];
  }
}

function writeAccounts(list: StoredAccount[]) {
  localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(list));
}

export const DEMO_ACCOUNT = { name: "Ana Dev", email: "demo@codigma.com", password: "123456" };

export class AuthError extends Error {}

export async function register(input: { name: string; email: string; password: string }): Promise<User> {
  await delay();
  const email = input.email.trim().toLowerCase();
  const list = readAccounts();
  if (list.some((a) => a.email === email)) throw new AuthError("Este e-mail já está cadastrado.");
  const account = { name: input.name.trim(), email, password: input.password };
  writeAccounts([...list, account]);
  return { name: account.name, email };
}

export async function login(input: { email: string; password: string }): Promise<User> {
  await delay();
  const email = input.email.trim().toLowerCase();
  if (email === DEMO_ACCOUNT.email && input.password === DEMO_ACCOUNT.password) {
    return { name: DEMO_ACCOUNT.name, email };
  }
  const found = readAccounts().find((a) => a.email === email);
  if (!found || found.password !== input.password) throw new AuthError("E-mail ou senha incorretos.");
  return { name: found.name, email: found.email };
}

export async function recoverPassword(email: string): Promise<void> {
  await delay();
  // A real backend would send an e-mail. Here we always succeed to avoid leaking which e-mails exist.
  void email;
}
