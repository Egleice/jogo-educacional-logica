/** Ranking service (mock). Later: GET /api/ranking. */
import { levelFromXp } from "@/lib/game/progression";
import type { Equipped } from "@/lib/game/types";

export interface RankingPlayer {
  id: string;
  name: string;
  xp: number;
  level: number;
  equipped: Equipped;
  isYou?: boolean;
}

const MOCK: Omit<RankingPlayer, "level">[] = [
  { id: "p1", name: "Lucas Byte", xp: 2450, equipped: { chapeu: "coroa", oculos: "oculos-sol" } },
  { id: "p2", name: "Marina Loop", xp: 2120, equipped: { chapeu: "bone-java", roupa: "moletom-verde" } },
  { id: "p3", name: "Pedro Array", xp: 1890, equipped: { oculos: "oculos-nerd", acessorio: "fone" } },
  { id: "p4", name: "Bia Boolean", xp: 1540, equipped: { chapeu: "cartola" } },
  { id: "p5", name: "Rafa Scanner", xp: 1310, equipped: { roupa: "jaleco-dev" } },
  { id: "p6", name: "Duda Switch", xp: 980, equipped: { chapeu: "bone-azul" } },
  { id: "p7", name: "Gabi Método", xp: 760, equipped: { oculos: "oculos-pixel" } },
  { id: "p8", name: "Theo Static", xp: 540, equipped: { mochila: "mochila-verde" } },
  { id: "p9", name: "Nina Char", xp: 320, equipped: {} },
  { id: "p10", name: "Caio Void", xp: 150, equipped: { acessorio: "gravata-bug" } },
];

export async function getRanking(you?: { name: string; xp: number; equipped: Equipped }): Promise<RankingPlayer[]> {
  const list: RankingPlayer[] = MOCK.map((p) => ({ ...p, level: levelFromXp(p.xp).level }));
  if (you) list.push({ id: "you", name: you.name, xp: you.xp, equipped: you.equipped, level: levelFromXp(you.xp).level, isYou: true });
  return list.sort((a, b) => b.xp - a.xp);
}
