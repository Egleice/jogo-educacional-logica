/**
 * Labirinto do Javi — pure simulation logic.
 * Grid legend: # wall, . floor, S start, G goal, K key, D door (needs key), C coffee bean
 */
export type Dir = 0 | 1 | 2 | 3; // 0 N, 1 E, 2 S, 3 W
export type BasicCmd = "frente" | "esquerda" | "direita";
export type ProgramItem = { type: BasicCmd } | { type: "repetir"; times: number; body: BasicCmd[] };

export interface MazeLevel {
  id: string;
  title: string;
  grid: string[];
  startDir: Dir;
  goal: string;
  hint: string;
  reward: { xp: number; coins: number };
}

export const CMD_LABEL: Record<BasicCmd, string> = {
  frente: "Andar para frente",
  esquerda: "Virar à esquerda",
  direita: "Virar à direita",
};

export const MAZE_LEVELS: MazeLevel[] = [
  {
    id: "m1",
    title: "Trilha do Grão",
    grid: ["#######", "#S..C.#", "#####.#", "#####G#", "#######"],
    startDir: 1,
    goal: "Leve o Javi até a bandeira. Pegue o grão de café no caminho!",
    hint: "Ande 4 vezes para frente, vire à direita e ande mais 2. Use Repetir para economizar comandos.",
    reward: { xp: 30, coins: 15 },
  },
  {
    id: "m2",
    title: "A Porta Trancada",
    grid: ["#########", "#S.C...K#", "#######.#", "#G..D...#", "#########"],
    startDir: 1,
    goal: "A porta 🚪 só abre com a chave 🔑. Pegue a chave antes de passar!",
    hint: "Repetir 6× frente até a chave, vire à direita, desça 2, vire à direita e repita 6× frente.",
    reward: { xp: 40, coins: 20 },
  },
  {
    id: "m3",
    title: "Escadaria do Loop",
    grid: ["########", "#S.#####", "##.C####", "###..###", "####.C##", "#####.G#", "########"],
    startDir: 1,
    goal: "Um caminho em escada! Descubra o padrão que se repete.",
    hint: "Depois do primeiro passo, o padrão é: direita, frente, esquerda, frente. Coloque-o dentro de um Repetir.",
    reward: { xp: 50, coins: 25 },
  },
];

export interface Frame {
  x: number;
  y: number;
  dir: Dir;
  hasKey: boolean;
  beans: string[];
  cmdIndex: number; // index in expanded list (-1 = start)
  programIndex: number;
}

export interface SimResult {
  frames: Frame[];
  success: boolean;
  failStep?: number; // 1-based step of expanded command
  failProgramIndex?: number;
  reason?: "parede" | "porta" | "incompleto";
  message: string;
  beansTotal: number;
}

export function expandProgram(program: ProgramItem[]): { cmd: BasicCmd; programIndex: number }[] {
  const out: { cmd: BasicCmd; programIndex: number }[] = [];
  program.forEach((item, programIndex) => {
    if (item.type === "repetir") {
      for (let i = 0; i < item.times; i++) item.body.forEach((cmd) => out.push({ cmd, programIndex }));
    } else out.push({ cmd: item.type, programIndex });
  });
  return out;
}

export function findCell(grid: string[], ch: string): { x: number; y: number } {
  for (let y = 0; y < grid.length; y++) {
    const x = grid[y]!.indexOf(ch);
    if (x >= 0) return { x, y };
  }
  return { x: 0, y: 0 };
}

const DX = [0, 1, 0, -1];
const DY = [-1, 0, 1, 0];

export function simulate(level: MazeLevel, program: ProgramItem[]): SimResult {
  const start = findCell(level.grid, "S");
  const goal = findCell(level.grid, "G");
  const beansTotal = level.grid.join("").split("C").length - 1;
  let f: Frame = { ...start, dir: level.startDir, hasKey: false, beans: [], cmdIndex: -1, programIndex: -1 };
  const frames: Frame[] = [f];
  const steps = expandProgram(program);

  for (let i = 0; i < steps.length; i++) {
    const { cmd, programIndex } = steps[i]!;
    if (cmd === "esquerda") f = { ...f, dir: ((f.dir + 3) % 4) as Dir };
    else if (cmd === "direita") f = { ...f, dir: ((f.dir + 1) % 4) as Dir };
    else {
      const nx = f.x + DX[f.dir]!;
      const ny = f.y + DY[f.dir]!;
      const cell = level.grid[ny]?.[nx] ?? "#";
      if (cell === "#") {
        return {
          frames,
          success: false,
          failStep: i + 1,
          failProgramIndex: programIndex,
          reason: "parede",
          message: `Na etapa ${i + 1} ("${CMD_LABEL[cmd]}"), Javi bateu em uma parede. Antes desse passo ele precisava virar ou parar — confira a direção em que ele estava olhando.`,
          beansTotal,
        };
      }
      if (cell === "D" && !f.hasKey) {
        return {
          frames,
          success: false,
          failStep: i + 1,
          failProgramIndex: programIndex,
          reason: "porta",
          message: `Na etapa ${i + 1}, Javi chegou à porta sem a chave. A porta é como um if: só abre SE ele tiver a chave. Passe pela chave 🔑 primeiro.`,
          beansTotal,
        };
      }
      const key = `${nx},${ny}`;
      f = {
        ...f,
        x: nx,
        y: ny,
        hasKey: f.hasKey || cell === "K",
        beans: cell === "C" && !f.beans.includes(key) ? [...f.beans, key] : f.beans,
      };
    }
    f = { ...f, cmdIndex: i, programIndex };
    frames.push(f);
    if (f.x === goal.x && f.y === goal.y) {
      return { frames, success: true, message: "Javi chegou ao destino!", beansTotal };
    }
  }
  const dist = Math.abs(goal.x - f.x) + Math.abs(goal.y - f.y);
  return {
    frames,
    success: false,
    failStep: steps.length,
    reason: "incompleto",
    message:
      steps.length === 0
        ? "Nenhum comando foi adicionado. Monte uma sequência antes de executar!"
        : `A sequência acabou e Javi ainda está a ${dist} casa(s) do destino. Adicione mais comandos ao final ou aumente as repetições.`,
    beansTotal,
  };
}
