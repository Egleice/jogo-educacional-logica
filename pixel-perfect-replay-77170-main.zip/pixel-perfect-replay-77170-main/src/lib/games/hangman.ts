/** Forca da Programação — pure logic. */
export const MAX_WRONG = 6;

export interface HangmanWord {
  word: string;
  hint: string;
  meaning: string;
  example: string;
}

export const HANGMAN_WORDS: HangmanWord[] = [
  { word: "public", hint: "Modificador que deixa algo visível para todos.", meaning: "public é um modificador de acesso: classes, métodos ou atributos public podem ser usados de qualquer lugar do programa.", example: "public class Jogo { }" },
  { word: "static", hint: "Pertence à classe, não a um objeto.", meaning: "static indica que o membro pertence à classe. Por isso chamamos main sem criar um objeto.", example: "public static void main(String[] args)" },
  { word: "String", hint: "Tipo usado para guardar textos.", meaning: "String representa uma sequência de caracteres. Valores ficam entre aspas duplas.", example: 'String nome = "Javi";' },
  { word: "int", hint: "Tipo para números inteiros.", meaning: "int é o tipo primitivo para números inteiros, como 10, -3 ou 2026.", example: "int moedas = 50;" },
  { word: "length", hint: "Diz o tamanho de um vetor.", meaning: "length informa quantos elementos um vetor tem (em String, usamos o método length()).", example: "int tam = notas.length;" },
  { word: "while", hint: "Laço que repete enquanto a condição for verdadeira.", meaning: "while repete um bloco enquanto sua condição for true. Atualize a variável para não criar um laço infinito!", example: "while (vida > 0) { jogar(); }" },
  { word: "class", hint: "Molde onde todo código Java vive.", meaning: "class define uma classe — o molde que agrupa atributos e métodos. Todo programa Java tem pelo menos uma.", example: "public class Javi { }" },
  { word: "void", hint: "Método que não devolve nada.", meaning: "void é o tipo de retorno de métodos que executam uma ação sem devolver valor.", example: "static void pular() { }" },
  { word: "return", hint: "Devolve um valor de um método.", meaning: "return encerra o método e devolve um valor para quem o chamou.", example: "return a + b;" },
  { word: "boolean", hint: "Só pode ser true ou false.", meaning: "boolean guarda valores lógicos: true (verdadeiro) ou false (falso).", example: "boolean venceu = true;" },
];

export const normalize = (s: string) => s.toLowerCase();

export function maskedWord(word: string, guessed: string[]): string[] {
  return word.split("").map((ch) => (guessed.includes(normalize(ch)) ? ch : "_"));
}

export function wrongCount(word: string, guessed: string[]): number {
  const w = normalize(word);
  return guessed.filter((g) => !w.includes(g)).length;
}

export function status(word: string, guessed: string[]): "jogando" | "venceu" | "perdeu" {
  if (wrongCount(word, guessed) >= MAX_WRONG) return "perdeu";
  if (maskedWord(word, guessed).every((c) => c !== "_")) return "venceu";
  return "jogando";
}
