/** Organize o Código — pure helpers. */
export interface OrganizeChallenge {
  id: string;
  title: string;
  topic: string;
  lines: string[]; // correct order
  explanation: string;
  reward: { xp: number; coins: number };
}

export const ORGANIZE_CHALLENGES: OrganizeChallenge[] = [
  {
    id: "o-variaveis",
    title: "Calculando o troco",
    topic: "Variáveis",
    lines: ["double preco = 4.5;", "double pago = 10.0;", "double troco = pago - preco;", 'System.out.println("Troco: " + troco);'],
    explanation: "As variáveis precisam existir antes de serem usadas: primeiro preco e pago, depois o cálculo do troco e, por fim, a exibição.",
    reward: { xp: 25, coins: 10 },
  },
  {
    id: "o-condicional",
    title: "Passou de fase?",
    topic: "Condicionais",
    lines: ["int pontos = 80;", "if (pontos >= 70) {", '    System.out.println("Fase concluída!");', "} else {", '    System.out.println("Tente de novo");', "}"],
    explanation: "Declaramos pontos, abrimos o if com a condição, colocamos o bloco verdadeiro, o else com o bloco falso e fechamos a chave.",
    reward: { xp: 30, coins: 12 },
  },
  {
    id: "o-repeticao",
    title: "Contagem regressiva",
    topic: "Repetição",
    lines: ["int n = 3;", "while (n > 0) {", "    System.out.println(n);", "    n--;", "}", 'System.out.println("Já!");'],
    explanation: "O contador é criado antes do while; dentro do laço mostramos n e o diminuímos; depois que o laço termina, mostramos \"Já!\".",
    reward: { xp: 35, coins: 15 },
  },
  {
    id: "o-metodo",
    title: "Método de bônus",
    topic: "Métodos",
    lines: ["static int bonus(int xp) {", "    int extra = xp / 10;", "    return xp + extra;", "}", "", "System.out.println(bonus(100));"],
    explanation: "A assinatura abre o método, calculamos o extra, retornamos o total e fechamos o método. A chamada fica fora dele.",
    reward: { xp: 40, coins: 18 },
  },
].map((c) => ({ ...c, lines: c.lines.filter((l) => l !== "") }));

/** For each position, whether the line placed there is the expected one. */
export function checkOrder(attempt: string[], correct: string[]): boolean[] {
  return correct.map((line, i) => attempt[i] === line);
}

/** Deterministic-enough shuffle that never returns the original order (for 2+ distinct lines). */
export function shuffleLines(lines: string[], rand: () => number = Math.random): string[] {
  const out = [...lines];
  for (let attempt = 0; attempt < 10; attempt++) {
    for (let i = out.length - 1; i > 0; i--) {
      const j = Math.floor(rand() * (i + 1));
      [out[i], out[j]] = [out[j]!, out[i]!];
    }
    if (out.some((l, i) => l !== lines[i])) return out;
  }
  return [...out.slice(1), out[0]!];
}
