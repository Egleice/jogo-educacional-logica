import type { Unit } from "@/data/units";

export const TONE_BG: Record<Unit["tone"], string> = {
  primary: "bg-primary text-primary-foreground",
  secondary: "bg-secondary text-secondary-foreground",
  success: "bg-success text-success-foreground",
  plum: "bg-plum text-foreground",
  destructive: "bg-destructive text-destructive-foreground",
};

export const TONE_SHADOW: Record<Unit["tone"], string> = {
  primary: "shadow-[0_6px_0_0_var(--primary-shade)]",
  secondary: "shadow-[0_6px_0_0_var(--secondary-shade)]",
  success: "shadow-[0_6px_0_0_var(--success-shade)]",
  plum: "shadow-[0_6px_0_0_var(--plum-shade)]",
  destructive: "shadow-[0_6px_0_0_var(--destructive-shade)]",
};
