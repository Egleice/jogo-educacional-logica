export type Slot = "chapeu" | "oculos" | "roupa" | "mochila" | "acessorio";
export type Equipped = Partial<Record<Slot, string>>;

export interface User {
  name: string;
  email: string;
}

export type HistoryKind = "atividade" | "jogo" | "loja" | "missao" | "conquista";

export interface HistoryEntry {
  id: string;
  date: string; // ISO
  kind: HistoryKind;
  title: string;
  xp: number;
  coins: number;
  detail?: string;
}

export interface AnswerRecord {
  questionId: string;
  source: string; // unit id or game id
  correct: boolean;
  date: string;
}

export interface UnitProgress {
  completed: boolean;
  bestScore: number; // 0..1
  stars: number; // 0..3
  attempts: number;
}

export interface DailyState {
  date: string; // YYYY-MM-DD
  activities: number;
  correct: number;
  games: number;
  claimed: string[];
}

export interface GameStats {
  played: number;
  wins: number;
}

export interface LastPlayed {
  kind: "unidade" | "jogo";
  id: string;
  title: string;
}

export interface GameState {
  user: User | null;
  xp: number;
  coins: number;
  streak: number;
  lastStudyDate: string | null;
  units: Record<string, UnitProgress>;
  history: HistoryEntry[];
  answers: AnswerRecord[];
  owned: string[];
  equipped: Equipped;
  daily: DailyState;
  games: Record<string, GameStats>;
  lastPlayed: LastPlayed | null;
  achievements: string[];
}
