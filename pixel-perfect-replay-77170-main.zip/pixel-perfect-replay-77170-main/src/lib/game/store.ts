/**
 * Player progress store (local, per user e-mail).
 * Persisted in localStorage while there's no backend; every mutation goes through
 * an action here so it can later be mirrored to REST endpoints.
 */
import { useSyncExternalStore } from "react";
import {
  ACHIEVEMENTS,
  DAILY_MISSIONS,
  REWARD_PER_CORRECT,
  UNIT_COMPLETION_BONUS,
  ensureDaily,
  freshDaily,
  nextStreak,
  starsForScore,
  todayKey,
} from "./progression";
import type { Equipped, GameState, HistoryEntry, LastPlayed, Slot, User } from "./types";

const SESSION_KEY = "codigma:session";
const progressKey = (email: string) => `codigma:progress:${email}`;

export function initialState(user: User | null = null): GameState {
  return {
    user,
    xp: 0,
    coins: 50,
    streak: 0,
    lastStudyDate: null,
    units: {},
    history: [],
    answers: [],
    owned: [],
    equipped: {},
    daily: freshDaily(todayKey()),
    games: {},
    lastPlayed: null,
    achievements: [],
  };
}

type Snapshot = GameState & { ready: boolean };

const SERVER_SNAPSHOT: Snapshot = { ...initialState(), ready: false };
let state: Snapshot | null = null;
const listeners = new Set<() => void>();

function load(): Snapshot {
  try {
    const session = localStorage.getItem(SESSION_KEY);
    if (!session) return { ...initialState(), ready: true };
    const user = JSON.parse(session) as User;
    const raw = localStorage.getItem(progressKey(user.email));
    const saved = raw ? (JSON.parse(raw) as Partial<GameState>) : {};
    const merged = { ...initialState(user), ...saved, user };
    merged.daily = ensureDaily(merged.daily, todayKey());
    return { ...merged, ready: true };
  } catch {
    return { ...initialState(), ready: true };
  }
}

function getSnapshot(): Snapshot {
  if (!state) state = load();
  return state;
}

function persist(s: GameState) {
  if (!s.user) return;
  const { ...data } = s as Snapshot;
  delete (data as Partial<Snapshot>).ready;
  localStorage.setItem(progressKey(s.user.email), JSON.stringify(data));
}

function set(updater: (s: GameState) => GameState) {
  const prev = getSnapshot();
  let next = updater({ ...prev, daily: ensureDaily(prev.daily, todayKey()) });
  next = withAchievements(next);
  state = { ...next, ready: true };
  persist(state);
  listeners.forEach((l) => l());
}

function subscribe(l: () => void) {
  listeners.add(l);
  return () => listeners.delete(l);
}

export function useGame(): Snapshot {
  return useSyncExternalStore(subscribe, getSnapshot, () => SERVER_SNAPSHOT);
}

export function getGameState(): Snapshot {
  return getSnapshot();
}

const uid = () => Math.random().toString(36).slice(2, 10);

function addHistory(s: GameState, entry: Omit<HistoryEntry, "id" | "date">): GameState {
  const h: HistoryEntry = { ...entry, id: uid(), date: new Date().toISOString() };
  return { ...s, history: [h, ...s.history].slice(0, 80) };
}

function markStudy(s: GameState): GameState {
  const today = todayKey();
  return { ...s, streak: nextStreak(s.lastStudyDate, today, s.streak), lastStudyDate: today };
}

function withAchievements(s: GameState): GameState {
  const newly = ACHIEVEMENTS.filter((a) => !s.achievements.includes(a.id) && a.check(s));
  if (newly.length === 0) return s;
  let next: GameState = { ...s, achievements: [...s.achievements, ...newly.map((a) => a.id)] };
  for (const a of newly) {
    next = addHistory(next, { kind: "conquista", title: `Conquista: ${a.title}`, xp: 0, coins: 0, detail: a.description });
  }
  return next;
}

// ---------- actions ----------

export const gameActions = {
  signIn(user: User) {
    localStorage.setItem(SESSION_KEY, JSON.stringify(user));
    state = load();
    listeners.forEach((l) => l());
  },
  signOut() {
    localStorage.removeItem(SESSION_KEY);
    state = { ...initialState(), ready: true };
    listeners.forEach((l) => l());
  },

  /** Record one answered question. Returns the reward granted. */
  recordAnswer(questionId: string, source: string, correct: boolean) {
    const reward = correct ? { ...REWARD_PER_CORRECT } : { xp: 0, coins: 0 };
    set((s) => ({
      ...markStudy(s),
      xp: s.xp + reward.xp,
      coins: s.coins + reward.coins,
      answers: [...s.answers, { questionId, source, correct, date: new Date().toISOString() }].slice(-500),
      daily: { ...s.daily, correct: s.daily.correct + (correct ? 1 : 0) },
    }));
    return reward;
  },

  /** Finish a unit activity with a score 0..1. Returns stars and bonus. */
  completeUnit(unitId: string, title: string, score: number) {
    const stars = starsForScore(score);
    let bonus = { xp: 0, coins: 0 };
    set((s) => {
      const prev = s.units[unitId] ?? { completed: false, bestScore: 0, stars: 0, attempts: 0 };
      const passed = stars > 0;
      const firstClear = passed && !prev.completed;
      const extraStars = Math.max(0, stars - prev.stars);
      bonus = {
        xp: firstClear ? UNIT_COMPLETION_BONUS.xp : 0,
        coins: extraStars * UNIT_COMPLETION_BONUS.coinsPerStar,
      };
      const next: GameState = {
        ...s,
        xp: s.xp + bonus.xp,
        coins: s.coins + bonus.coins,
        units: {
          ...s.units,
          [unitId]: {
            completed: prev.completed || passed,
            bestScore: Math.max(prev.bestScore, score),
            stars: Math.max(prev.stars, stars),
            attempts: prev.attempts + 1,
          },
        },
        daily: { ...s.daily, activities: s.daily.activities + 1 },
        lastPlayed: { kind: "unidade", id: unitId, title },
      };
      return addHistory(next, {
        kind: "atividade",
        title: `Atividade: ${title}`,
        xp: bonus.xp,
        coins: bonus.coins,
        detail: `${Math.round(score * 100)}% de acertos · ${stars} estrela(s)`,
      });
    });
    return { stars, bonus };
  },

  /** Finish a mini-game round. */
  recordGame(gameId: string, title: string, won: boolean, reward: { xp: number; coins: number }) {
    const granted = won ? reward : { xp: Math.round(reward.xp / 4), coins: 0 };
    set((s) => {
      const g = s.games[gameId] ?? { played: 0, wins: 0 };
      const next: GameState = {
        ...markStudy(s),
        xp: s.xp + granted.xp,
        coins: s.coins + granted.coins,
        games: { ...s.games, [gameId]: { played: g.played + 1, wins: g.wins + (won ? 1 : 0) } },
        daily: { ...s.daily, games: s.daily.games + 1 },
        lastPlayed: { kind: "jogo", id: gameId, title } as LastPlayed,
      };
      return addHistory(next, {
        kind: "jogo",
        title: `${title}: ${won ? "vitória" : "tentativa"}`,
        xp: granted.xp,
        coins: granted.coins,
      });
    });
    return granted;
  },

  buyItem(itemId: string, name: string, price: number): boolean {
    const s = getSnapshot();
    if (s.owned.includes(itemId) || s.coins < price) return false;
    set((st) => addHistory({ ...st, coins: st.coins - price, owned: [...st.owned, itemId] }, {
      kind: "loja",
      title: `Comprou: ${name}`,
      xp: 0,
      coins: -price,
    }));
    return true;
  },

  equip(slot: Slot, itemId: string | null) {
    set((s) => {
      const equipped: Equipped = { ...s.equipped };
      if (itemId) equipped[slot] = itemId;
      else delete equipped[slot];
      return { ...s, equipped };
    });
  },

  claimMission(missionId: string): boolean {
    const mission = DAILY_MISSIONS.find((m) => m.id === missionId);
    const s = getSnapshot();
    const daily = ensureDaily(s.daily, todayKey());
    if (!mission || daily.claimed.includes(missionId) || daily[mission.metric] < mission.target) return false;
    set((st) =>
      addHistory(
        {
          ...st,
          xp: st.xp + mission.reward.xp,
          coins: st.coins + mission.reward.coins,
          daily: { ...st.daily, claimed: [...st.daily.claimed, missionId] },
        },
        { kind: "missao", title: `Missão: ${mission.title}`, xp: mission.reward.xp, coins: mission.reward.coins },
      ),
    );
    return true;
  },
};
