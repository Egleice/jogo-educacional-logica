import type { DailyState, GameState, UnitProgress } from "./types";

/** Rewards per correct answer and per completed unit. */
export const REWARD_PER_CORRECT = { xp: 10, coins: 5 } as const;
export const UNIT_COMPLETION_BONUS = { xp: 30, coinsPerStar: 10 } as const;
/** Minimum score (0..1) to complete a unit and unlock the next one. */
export const PASS_SCORE = 0.6;

/** XP needed to go from `level` to `level + 1`. Level 1 → 2 needs 100, then +50 each level. */
export function xpToNext(level: number): number {
  return 100 + (level - 1) * 50;
}

export function levelFromXp(xp: number): { level: number; into: number; needed: number } {
  let level = 1;
  let remaining = Math.max(0, Math.floor(xp));
  while (remaining >= xpToNext(level)) {
    remaining -= xpToNext(level);
    level += 1;
  }
  return { level, into: remaining, needed: xpToNext(level) };
}

export function starsForScore(score: number): number {
  if (score >= 1) return 3;
  if (score >= 0.8) return 2;
  if (score >= PASS_SCORE) return 1;
  return 0;
}

export function todayKey(d: Date = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function dayDiff(a: string, b: string): number {
  const [ay = 0, am = 1, ad = 1] = a.split("-").map(Number);
  const [by = 0, bm = 1, bd = 1] = b.split("-").map(Number);
  const ta = Date.UTC(ay, am - 1, ad);
  const tb = Date.UTC(by, bm - 1, bd);
  return Math.round((tb - ta) / 86400000);
}

/** Streak: same day keeps it, next day adds 1, any gap restarts at 1. */
export function nextStreak(lastStudyDate: string | null, today: string, streak: number): number {
  if (!lastStudyDate) return 1;
  const diff = dayDiff(lastStudyDate, today);
  if (diff <= 0) return Math.max(streak, 1);
  if (diff === 1) return streak + 1;
  return 1;
}

/** Unit at `index` is unlocked when it's the first one or the previous one is completed. */
export function isUnitUnlocked(
  index: number,
  unitIds: string[],
  progress: Record<string, UnitProgress>,
): boolean {
  if (index <= 0) return true;
  return Boolean(progress[unitIds[index - 1] ?? ""]?.completed);
}

export function freshDaily(date: string): DailyState {
  return { date, activities: 0, correct: 0, games: 0, claimed: [] };
}

export function ensureDaily(daily: DailyState | undefined, today: string): DailyState {
  if (!daily || daily.date !== today) return freshDaily(today);
  return daily;
}

export interface DailyMission {
  id: string;
  title: string;
  metric: "activities" | "correct" | "games";
  target: number;
  reward: { xp: number; coins: number };
}

export const DAILY_MISSIONS: DailyMission[] = [
  { id: "m-atividade", title: "Conclua 1 atividade", metric: "activities", target: 1, reward: { xp: 20, coins: 15 } },
  { id: "m-acertos", title: "Acerte 5 questões", metric: "correct", target: 5, reward: { xp: 25, coins: 20 } },
  { id: "m-jogo", title: "Jogue 1 mini-game", metric: "games", target: 1, reward: { xp: 15, coins: 10 } },
];

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  check: (s: GameState) => boolean;
}

export const ACHIEVEMENTS: Achievement[] = [
  { id: "primeiro-passo", title: "Primeiro passo", description: "Responda sua primeira questão.", icon: "👣", check: (s) => s.answers.length >= 1 },
  { id: "dez-acertos", title: "Cérebro aquecido", description: "Acerte 10 questões.", icon: "🧠", check: (s) => s.answers.filter((a) => a.correct).length >= 10 },
  { id: "primeira-unidade", title: "Explorador", description: "Conclua sua primeira unidade.", icon: "🗺️", check: (s) => Object.values(s.units).some((u) => u.completed) },
  { id: "tres-estrelas", title: "Perfeccionista", description: "Ganhe 3 estrelas em uma unidade.", icon: "⭐", check: (s) => Object.values(s.units).some((u) => u.stars === 3) },
  { id: "gamer", title: "Gamer de código", description: "Vença um mini-game.", icon: "🎮", check: (s) => Object.values(s.games).some((g) => g.wins > 0) },
  { id: "estilo", title: "Estiloso", description: "Compre um acessório para o Javi.", icon: "🎩", check: (s) => s.owned.length > 0 },
  { id: "sequencia-3", title: "Café diário", description: "Estude 3 dias seguidos.", icon: "🔥", check: (s) => s.streak >= 3 },
  { id: "nivel-5", title: "Dev em ascensão", description: "Alcance o nível 5.", icon: "🚀", check: (s) => levelFromXp(s.xp).level >= 5 },
];

export function accuracy(state: Pick<GameState, "answers">): number {
  if (state.answers.length === 0) return 0;
  return state.answers.filter((a) => a.correct).length / state.answers.length;
}
