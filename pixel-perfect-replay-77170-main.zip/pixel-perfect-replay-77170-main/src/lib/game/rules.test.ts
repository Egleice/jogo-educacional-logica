import { describe, expect, it } from "vitest";
import { isUnitUnlocked, levelFromXp, nextStreak, starsForScore } from "./progression";
import { MAZE_LEVELS, simulate, type ProgramItem } from "../games/maze";
import { MAX_WRONG, status } from "../games/hangman";
import { checkOrder } from "../games/organize";

describe("progressão", () => {
  it("nível 1→2 precisa de 100 XP", () => {
    expect(levelFromXp(99).level).toBe(1);
    expect(levelFromXp(100).level).toBe(2);
  });

  it("sequência: dia seguinte soma 1, pular um dia reinicia em 1", () => {
    expect(nextStreak("2026-10-29", "2026-10-30", 4)).toBe(5);
    expect(nextStreak("2026-10-27", "2026-10-30", 4)).toBe(1);
    expect(nextStreak("2026-10-30", "2026-10-30", 4)).toBe(4);
  });

  it("próxima unidade só desbloqueia após concluir a anterior", () => {
    const ids = ["a", "b"];
    expect(isUnitUnlocked(1, ids, {})).toBe(false);
    expect(isUnitUnlocked(1, ids, { a: { completed: true, bestScore: 1, stars: 3, attempts: 1 } })).toBe(true);
  });

  it("menos de 60% de acertos não conclui a unidade", () => {
    expect(starsForScore(0.4)).toBe(0);
    expect(starsForScore(0.6)).toBe(1);
  });
});

describe("mini-games", () => {
  it("forca: seis erros perdem o jogo", () => {
    expect(MAX_WRONG).toBe(6);
    expect(status("int", ["a", "b", "c", "d", "e"])).toBe("jogando");
    expect(status("int", ["a", "b", "c", "d", "e", "f"])).toBe("perdeu");
  });

  it("labirinto 1: a sequência correta chega ao destino", () => {
    const program: ProgramItem[] = [
      { type: "repetir", times: 4, body: ["frente"] },
      { type: "direita" },
      { type: "repetir", times: 2, body: ["frente"] },
    ];
    expect(simulate(MAZE_LEVELS[0]!, program).success).toBe(true);
  });

  it("labirinto 2: passar pela porta sem chave falha", () => {
    const program: ProgramItem[] = [
      { type: "repetir", times: 6, body: ["frente"] },
      { type: "direita" },
      { type: "repetir", times: 2, body: ["frente"] },
      { type: "direita" },
      { type: "repetir", times: 6, body: ["frente"] },
    ];
    expect(simulate(MAZE_LEVELS[1]!, program).success).toBe(true);
    const noKey: ProgramItem[] = [{ type: "repetir", times: 5, body: ["frente"] }];
    expect(simulate(MAZE_LEVELS[1]!, noKey).reason).toBe("incompleto");
  });

  it("labirinto 3: padrão em loop resolve a escada", () => {
    const program: ProgramItem[] = [
      { type: "frente" },
      { type: "repetir", times: 4, body: ["direita", "frente", "esquerda", "frente"] },
    ];
    expect(simulate(MAZE_LEVELS[2]!, program).success).toBe(true);
  });

  it("organize: aponta exatamente as linhas fora de ordem", () => {
    expect(checkOrder(["b", "a", "c"], ["a", "b", "c"])).toEqual([false, false, true]);
  });
});
