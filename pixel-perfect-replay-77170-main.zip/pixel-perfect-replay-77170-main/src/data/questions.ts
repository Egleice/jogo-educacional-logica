export interface Option {
  text: string;
  /** Why this option is right or wrong — shown in the feedback. */
  why: string;
}

interface Base {
  id: string;
  prompt: string;
  /** Short explanation of the correct reasoning. */
  explanation: string;
  /** Programming concept practiced / to review. */
  concept: string;
}

export interface ChoiceQuestion extends Base {
  type: "multipla" | "vf" | "complete" | "saida" | "interprete";
  code?: string | undefined; // for "complete", contains ___ where the chosen option goes
  options: Option[];
  answer: number;
}

export interface ErrorQuestion extends Base {
  type: "erro";
  lines: string[];
  answer: number; // index of the wrong line
  fixedLine: string;
  /** Note per line explaining what it does (used when the student picks a correct line). */
  lineNotes: string[];
}

export interface OrderQuestion extends Base {
  type: "ordem";
  lines: string[]; // correct order
}

export type Question = ChoiceQuestion | ErrorQuestion | OrderQuestion;

export const QUESTION_TYPE_LABEL: Record<Question["type"], string> = {
  multipla: "Múltipla escolha",
  vf: "Verdadeiro ou falso",
  complete: "Complete o código",
  saida: "Qual é a saída?",
  interprete: "Interprete o código",
  erro: "Encontre o erro",
  ordem: "Organize as linhas",
};

export function vf(id: string, prompt: string, isTrue: boolean, whyTrue: string, whyFalse: string, explanation: string, concept: string, code?: string): ChoiceQuestion {
  return {
    id,
    type: "vf",
    prompt,
    code,
    options: [
      { text: "Verdadeiro", why: whyTrue },
      { text: "Falso", why: whyFalse },
    ],
    answer: isTrue ? 0 : 1,
    explanation,
    concept,
  };
}
