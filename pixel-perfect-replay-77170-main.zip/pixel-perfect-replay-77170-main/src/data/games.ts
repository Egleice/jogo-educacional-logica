export const GAMES = [
  { id: "labirinto", to: "/jogos/labirinto", icon: "🧭", title: "Labirinto do Javi", skill: "Sequência, condições e repetição", description: "Monte comandos para guiar o Javi até a bandeira, pegando chaves e grãos de café." },
  { id: "batalha", to: "/jogos/batalha", icon: "⚔️", title: "Batalha de Código", skill: "Desafios Java", description: "Vença bugs e monstros respondendo perguntas e corrigindo códigos." },
  { id: "forca", to: "/jogos/forca", icon: "🔤", title: "Forca da Programação", skill: "Palavras-chave do Java", description: "Descubra termos do Java com uma dica e seis tentativas." },
  { id: "organize", to: "/jogos/organize", icon: "🧩", title: "Organize o Código", skill: "Lógica e estrutura", description: "Coloque as linhas embaralhadas na ordem certa." },
] as const;
