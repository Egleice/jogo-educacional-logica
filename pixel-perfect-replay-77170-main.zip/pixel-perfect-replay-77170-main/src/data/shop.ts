/** Shop catalog (mock). Later: GET /api/shop/items. */
import type { Slot } from "@/lib/game/types";

export interface ShopItem {
  id: string;
  name: string;
  slot: Slot;
  price: number;
  description: string;
}

export const SLOT_LABEL: Record<Slot, string> = {
  chapeu: "Chapéus e bonés",
  oculos: "Óculos",
  roupa: "Roupas",
  mochila: "Mochilas",
  acessorio: "Acessórios dev",
};

export const SHOP_ITEMS: ShopItem[] = [
  { id: "bone-azul", name: "Boné Azul", slot: "chapeu", price: 40, description: "Clássico de aventureiro." },
  { id: "bone-java", name: "Boné Java", slot: "chapeu", price: 60, description: "Com o J de Java na frente." },
  { id: "explorador", name: "Chapéu Explorador", slot: "chapeu", price: 90, description: "Para desbravar o mapa." },
  { id: "cartola", name: "Cartola Elegante", slot: "chapeu", price: 120, description: "Para códigos refinados." },
  { id: "coroa", name: "Coroa do Ranking", slot: "chapeu", price: 250, description: "Só para os campeões." },
  { id: "oculos-nerd", name: "Óculos Nerd", slot: "oculos", price: 45, description: "+10 de concentração." },
  { id: "oculos-sol", name: "Óculos Escuros", slot: "oculos", price: 70, description: "Estilo sem bugs." },
  { id: "oculos-pixel", name: "Óculos Pixel", slot: "oculos", price: 110, description: "Deal with it." },
  { id: "moletom-verde", name: "Moletom Verde", slot: "roupa", price: 80, description: "Confortável para maratonar." },
  { id: "camisa-amarela", name: "Camisa Estrela", slot: "roupa", price: 65, description: "Brilha mais que o sol." },
  { id: "jaleco-dev", name: "Jaleco Dev", slot: "roupa", price: 130, description: "Com </> no peito." },
  { id: "mochila-verde", name: "Mochila Trilha", slot: "mochila", price: 75, description: "Cabe muitos grãos de café." },
  { id: "mochila-foguete", name: "Mochila Foguete", slot: "mochila", price: 180, description: "Rumo ao próximo nível!" },
  { id: "fone", name: "Fone Lo-fi", slot: "acessorio", price: 85, description: "Para programar no ritmo." },
  { id: "gravata-bug", name: "Gravata Borboleta Bug", slot: "acessorio", price: 55, description: "Um bug que dá estilo." },
  { id: "medalha", name: "Medalha de Honra", slot: "acessorio", price: 100, description: "Para heróis do código." },
];
