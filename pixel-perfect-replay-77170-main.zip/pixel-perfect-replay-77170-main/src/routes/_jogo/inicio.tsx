import { createFileRoute, Link } from "@tanstack/react-router";
import { Coins, Flame, Sparkles, Gift, Check, Play } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { XpBar } from "@/components/game/XpBar";
import { Javi } from "@/components/javi/Javi";
import { gameActions, useGame } from "@/lib/game/store";
import { DAILY_MISSIONS, isUnitUnlocked, levelFromXp } from "@/lib/game/progression";
import { UNITS, UNIT_IDS } from "@/data/units";
import { GAMES } from "@/data/games";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_jogo/inicio")({
  head: () => ({
    meta: [
      { title: "Início — CODIGMA" },
      { name: "description", content: "Seu painel de aventura: nível, XP, moedas, missões diárias e acesso rápido aos jogos." },
      { property: "og:title", content: "Início — CODIGMA" },
      { property: "og:description", content: "Seu painel de aventura no CODIGMA." },
    ],
  }),
  component: Home,
});

function greeting() {
  const h = new Date().getHours();
  return h < 12 ? "Bom dia" : h < 18 ? "Boa tarde" : "Boa noite";
}

function Home() {
  const game = useGame();
  const lvl = levelFromXp(game.xp);
  const firstName = game.user?.name.split(" ")[0] ?? "dev";
  const nextUnit = UNITS.find((u, i) => isUnitUnlocked(i, UNIT_IDS, game.units) && !game.units[u.id]?.completed) ?? UNITS[UNITS.length - 1]!;
  const last = game.lastPlayed;
  const javiLine =
    game.answers.length === 0
      ? "Vamos começar? A primeira fase é na Vila do Café!"
      : game.streak >= 3
        ? `${game.streak} dias seguidos! Você está pegando fogo! 🔥`
        : "Que tal completar uma missão diária hoje?";

  return (
    <div className="space-y-8">
      {/* Hero greeting */}
      <section className="game-card relative overflow-hidden p-6 sm:p-8">
        <div className="grid items-center gap-6 md:grid-cols-[auto_1fr_auto]">
          <Javi mood={game.streak >= 3 ? "animado" : "feliz"} size={130} equipped={game.equipped} className="mx-auto" />
          <div>
            <p className="font-display text-lg text-muted-foreground">{greeting()},</p>
            <h1 className="text-4xl font-bold sm:text-5xl">{firstName}! 👋</h1>
            <p className="mt-2 inline-block rounded-2xl bg-ink px-3 py-2 font-semibold">☕ {javiLine}</p>
            <div className="mt-5 max-w-xl">
              <div className="mb-1 flex items-baseline justify-between font-display">
                <span className="text-xl font-bold text-primary">Nível {lvl.level}</span>
                <span className="text-sm text-muted-foreground">
                  {lvl.into} / {lvl.needed} XP
                </span>
              </div>
              <XpBar value={lvl.into} max={lvl.needed} />
            </div>
          </div>
          <div className="flex flex-row justify-center gap-3 md:flex-col">
            <Stat icon={<Sparkles />} label="XP total" value={game.xp} className="bg-secondary text-secondary-foreground -rotate-2" />
            <Stat icon={<Coins />} label="Moedas" value={game.coins} className="bg-primary text-primary-foreground rotate-1" />
            <Stat icon={<Flame />} label="Dias seguidos" value={game.streak} className="bg-destructive text-destructive-foreground -rotate-1" />
          </div>
        </div>
      </section>

      <div className="grid gap-6 lg:grid-cols-[1.3fr_1fr]">
        {/* Continue */}
        <section className="space-y-4">
          <h2 className="text-2xl font-bold">Continue a aventura</h2>
          <Link
            to="/aprender/$unidadeId"
            params={{ unidadeId: nextUnit.id }}
            className="press group flex items-center gap-5 rounded-3xl border-[3px] border-ink bg-plum p-5 shadow-[0_8px_0_0_var(--plum-shade)]"
          >
            <span className="grid h-20 w-20 shrink-0 place-items-center rounded-full border-[3px] border-ink bg-primary text-4xl transition-transform group-hover:rotate-12">
              {nextUnit.icon}
            </span>
            <div className="flex-1">
              <p className="text-sm font-bold uppercase tracking-wide text-primary">Próxima fase · {nextUnit.area}</p>
              <p className="font-display text-2xl font-semibold">{nextUnit.title}</p>
              <p className="text-muted-foreground">{nextUnit.summary}</p>
            </div>
            <Play className="hidden h-10 w-10 text-primary sm:block" />
          </Link>
          {last && (
            <p className="text-muted-foreground">
              Última jogada:{" "}
              {last.kind === "unidade" ? (
                <Link to="/aprender/$unidadeId" params={{ unidadeId: last.id }} className="font-bold text-secondary hover:underline">
                  {last.title}
                </Link>
              ) : (
                <Link to="/jogos" className="font-bold text-secondary hover:underline">
                  {last.title}
                </Link>
              )}
            </p>
          )}

          <h2 className="pt-2 text-2xl font-bold">Jogos rápidos</h2>
          <div className="grid grid-cols-2 gap-4">
            {GAMES.map((g, i) => (
              <Link
                key={g.id}
                to={g.to}
                className={cn(
                  "press game-card flex flex-col gap-2 p-4 transition-transform hover:-translate-y-1",
                  i % 2 === 0 ? "-rotate-1" : "rotate-1",
                )}
              >
                <span className="text-4xl">{g.icon}</span>
                <span className="font-display text-lg font-semibold leading-tight">{g.title}</span>
                <span className="text-xs text-muted-foreground">{g.skill}</span>
              </Link>
            ))}
          </div>
        </section>

        {/* Daily missions */}
        <section className="rounded-3xl border-[3px] border-dashed border-primary/60 p-5">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">Missões diárias</h2>
            <Gift className="h-7 w-7 text-primary" />
          </div>
          <ul className="mt-4 space-y-4">
            {DAILY_MISSIONS.map((m) => {
              const progress = Math.min(game.daily[m.metric], m.target);
              const done = progress >= m.target;
              const claimed = game.daily.claimed.includes(m.id);
              return (
                <li key={m.id} className="game-panel p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="font-display text-lg font-semibold">{m.title}</p>
                      <p className="text-sm text-muted-foreground">
                        +{m.reward.xp} XP · +{m.reward.coins} moedas
                      </p>
                    </div>
                    {claimed ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-success px-3 py-1 text-sm font-bold text-success-foreground">
                        <Check className="h-4 w-4" /> Resgatada
                      </span>
                    ) : (
                      <Button
                        size="sm"
                        variant={done ? "default" : "outline"}
                        disabled={!done}
                        onClick={() => {
                          if (gameActions.claimMission(m.id)) toast.success(`Missão concluída! +${m.reward.xp} XP e +${m.reward.coins} moedas`);
                        }}
                      >
                        {done ? "Resgatar" : `${progress}/${m.target}`}
                      </Button>
                    )}
                  </div>
                  <XpBar value={progress} max={m.target} tone="success" className="mt-3 h-4" />
                </li>
              );
            })}
          </ul>
          <Button asChild variant="plum" className="mt-5 w-full">
            <Link to="/loja">🎩 Gastar moedas na loja do Javi</Link>
          </Button>
        </section>
      </div>
    </div>
  );
}

function Stat({ icon, label, value, className }: { icon: React.ReactNode; label: string; value: number; className?: string }) {
  return (
    <div className={cn("flex min-w-24 flex-col items-center rounded-2xl border-[3px] border-ink px-3 py-2 shadow-[0_4px_0_0_var(--ink)] [&_svg]:h-5 [&_svg]:w-5", className)}>
      {icon}
      <span className="font-display text-2xl font-bold leading-none">{value}</span>
      <span className="text-[11px] font-bold uppercase opacity-80">{label}</span>
    </div>
  );
}
