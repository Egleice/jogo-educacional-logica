import { createFileRoute, Link } from "@tanstack/react-router";
import { Lock, Star } from "lucide-react";
import { Javi } from "@/components/javi/Javi";
import { XpBar } from "@/components/game/XpBar";
import { useGame } from "@/lib/game/store";
import { isUnitUnlocked } from "@/lib/game/progression";
import { UNITS, UNIT_IDS } from "@/data/units";
import { TONE_BG, TONE_SHADOW } from "@/lib/game/tone";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_jogo/aprender/")({
  head: () => ({
    meta: [
      { title: "Mapa de aprendizado — CODIGMA" },
      { name: "description", content: "Explore 9 regiões e aprenda Java do básico ao avançado: variáveis, condicionais, laços, vetores e métodos." },
      { property: "og:title", content: "Mapa de aprendizado — CODIGMA" },
      { property: "og:description", content: "Explore 9 regiões e aprenda Java do básico ao avançado." },
    ],
  }),
  component: MapPage,
});

const STEP = 170;
const XS = [50, 76, 50, 24];

function MapPage() {
  const game = useGame();
  const completed = UNITS.filter((u) => game.units[u.id]?.completed).length;
  const currentIdx = UNITS.findIndex((u, i) => isUnitUnlocked(i, UNIT_IDS, game.units) && !game.units[u.id]?.completed);
  const height = UNITS.length * STEP + 40;
  const pts = UNITS.map((_, i) => ({ x: XS[i % XS.length]!, y: i * STEP + 70 }));
  const seg = (a: { x: number; y: number }, b: { x: number; y: number }) =>
    `M ${a.x} ${a.y} C ${a.x} ${(a.y + b.y) / 2}, ${b.x} ${(a.y + b.y) / 2}, ${b.x} ${b.y}`;

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-4xl font-bold">Mapa de aprendizado</h1>
          <p className="text-muted-foreground">Conclua cada fase com pelo menos 60% de acertos para desbloquear a próxima.</p>
        </div>
        <div className="w-full max-w-xs">
          <p className="mb-1 font-display font-semibold">
            {completed} de {UNITS.length} regiões conquistadas
          </p>
          <XpBar value={completed} max={UNITS.length} tone="success" />
        </div>
      </div>

      <div className="relative mx-auto max-w-2xl" style={{ height }}>
        <svg className="absolute inset-0 h-full w-full" viewBox={`0 0 100 ${height}`} preserveAspectRatio="none" aria-hidden>
          {pts.slice(1).map((p, i) => {
            const done = game.units[UNITS[i]!.id]?.completed;
            return (
              <g key={i}>
                <path d={seg(pts[i]!, p)} fill="none" stroke="var(--ink)" strokeWidth="22" vectorEffect="non-scaling-stroke" strokeLinecap="round" />
                <path
                  d={seg(pts[i]!, p)}
                  fill="none"
                  stroke={done ? "var(--primary)" : "var(--plum)"}
                  strokeWidth="10"
                  strokeDasharray={done ? "0" : "4 14"}
                  vectorEffect="non-scaling-stroke"
                  strokeLinecap="round"
                />
              </g>
            );
          })}
        </svg>

        {UNITS.map((u, i) => {
          const unlocked = isUnitUnlocked(i, UNIT_IDS, game.units);
          const prog = game.units[u.id];
          const isCurrent = i === currentIdx;
          const labelRight = XS[i % XS.length]! <= 50;
          return (
            <div key={u.id} className="absolute -translate-x-1/2 -translate-y-1/2" style={{ left: `${pts[i]!.x}%`, top: pts[i]!.y }}>
              <div className="relative flex flex-col items-center">
                {/* stars */}
                <div className="mb-1 flex gap-0.5">
                  {[0, 1, 2].map((s) => (
                    <Star key={s} className={cn("h-5 w-5", (prog?.stars ?? 0) > s ? "fill-primary text-primary" : "text-muted-foreground/40")} />
                  ))}
                </div>
                {unlocked ? (
                  <Link
                    to="/aprender/$unidadeId"
                    params={{ unidadeId: u.id }}
                    className={cn(
                      "press grid h-24 w-24 place-items-center rounded-full border-[4px] border-ink text-4xl transition-transform hover:scale-110",
                      TONE_BG[u.tone],
                      TONE_SHADOW[u.tone],
                      isCurrent && "ring-8 ring-primary/30",
                    )}
                    aria-label={`Fase ${u.order}: ${u.title}`}
                  >
                    {u.icon}
                  </Link>
                ) : (
                  <div
                    className="grid h-24 w-24 place-items-center rounded-full border-[4px] border-ink bg-muted text-muted-foreground shadow-[0_6px_0_0_var(--ink)]"
                    aria-label={`Fase ${u.order} bloqueada`}
                  >
                    <Lock className="h-9 w-9" />
                  </div>
                )}

                <div
                  className={cn(
                    "absolute top-8 w-40 sm:w-48",
                    labelRight ? "left-[calc(100%+12px)] text-left" : "right-[calc(100%+12px)] text-right",
                  )}
                >
                  <p className="text-xs font-bold uppercase tracking-wide text-primary">
                    Fase {u.order} · {u.area}
                  </p>
                  <p className={cn("font-display font-semibold leading-tight", !unlocked && "text-muted-foreground")}>{u.title}</p>
                </div>

                {isCurrent && (
                  <div className={cn("pointer-events-none absolute -top-16", labelRight ? "-left-20" : "-right-20")}>
                    <Javi mood="animado" size={70} equipped={game.equipped} />
                    <span className="absolute -top-4 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full border-2 border-ink bg-foreground px-2 text-xs font-bold text-ink">
                      Você está aqui!
                    </span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
