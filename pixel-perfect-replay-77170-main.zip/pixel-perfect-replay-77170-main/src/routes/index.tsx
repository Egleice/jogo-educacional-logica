import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/game/Logo";
import { Javi } from "@/components/javi/Javi";
import { useGame } from "@/lib/game/store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CODIGMA — Aprenda Java jogando com o Javi" },
      { name: "description", content: "Explore um mapa de aventuras, resolva desafios de lógica e aprenda Java com o Javi. Pense, programe, evolua." },
      { property: "og:title", content: "CODIGMA — Aprenda Java jogando com o Javi" },
      { property: "og:description", content: "Explore um mapa de aventuras, resolva desafios e aprenda Java com o Javi." },
    ],
  }),
  component: Landing,
});

const FEATURES = [
  { icon: "🗺️", title: "Mapa de fases", text: "9 regiões, da Vila do Café ao Vulcão da Revisão." },
  { icon: "🧩", title: "Desafios com explicação", text: "Errou? O Javi mostra o porquê e como corrigir." },
  { icon: "🎮", title: "4 mini-games", text: "Labirinto, batalha, forca e organize o código." },
  { icon: "🎩", title: "Personalize o Javi", text: "Troque moedas por chapéus, óculos e mochilas." },
];

function Landing() {
  const { user, ready } = useGame();
  const logged = ready && !!user;

  return (
    <div className="min-h-screen bg-background">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-4 py-5">
        <Logo />
        <div className="flex gap-2">
          {logged ? (
            <Button asChild size="sm">
              <Link to="/inicio">Continuar</Link>
            </Button>
          ) : (
            <>
              <Button asChild size="sm" variant="ghost">
                <Link to="/entrar">Entrar</Link>
              </Button>
              <Button asChild size="sm" variant="secondary">
                <Link to="/cadastro">Criar conta</Link>
              </Button>
            </>
          )}
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4">
        <section className="grid items-center gap-10 py-8 md:grid-cols-[1.15fr_1fr] md:py-16">
          <div>
            <span className="inline-flex -rotate-2 items-center gap-2 rounded-full border-[3px] border-ink bg-success px-4 py-1 font-display font-semibold text-success-foreground shadow-[0_4px_0_0_var(--ink)]">
              ☕ Pense, programe, evolua.
            </span>
            <h1 className="mt-6 text-5xl font-bold leading-[1.02] sm:text-6xl lg:text-7xl">
              Aprenda <span className="text-primary">Java</span> numa aventura de verdade.
            </h1>
            <p className="mt-5 max-w-lg text-lg text-muted-foreground">
              Olá! Eu sou o <b className="text-foreground">Javi</b>. Vamos explorar fases, vencer bugs e ganhar recompensas enquanto você aprende lógica de programação do zero.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg">
                <Link to={logged ? "/inicio" : "/cadastro"}>Começar a jogar</Link>
              </Button>
              {!logged && (
                <Button asChild size="lg" variant="outline">
                  <Link to="/entrar">Já tenho conta</Link>
                </Button>
              )}
            </div>
          </div>

          <div className="relative mx-auto">
            <div className="relative grid h-80 w-80 place-items-center rounded-full border-[3px] border-ink bg-card sm:h-96 sm:w-96">
              <div className="absolute inset-6 rounded-full border-[3px] border-dashed border-plum" />
              <Javi mood="animado" size={230} />
            </div>
            <span className="absolute -left-2 top-8 rotate-[-10deg] rounded-2xl border-[3px] border-ink bg-primary px-3 py-1 font-mono text-sm font-bold text-primary-foreground shadow-[0_4px_0_0_var(--ink)]">
              int xp = 100;
            </span>
            <span className="absolute -right-2 bottom-16 rotate-[8deg] rounded-2xl border-[3px] border-ink bg-secondary px-3 py-1 font-mono text-sm font-bold text-secondary-foreground shadow-[0_4px_0_0_var(--ink)]">
              while (aprendendo)
            </span>
            <span className="absolute bottom-2 left-6 text-4xl animate-bounce-soft">⭐</span>
          </div>
        </section>

        <section className="grid gap-4 pb-16 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((f, i) => (
            <div key={f.title} className={`game-card p-5 ${i % 2 ? "lg:translate-y-6" : ""}`}>
              <div className="grid h-14 w-14 place-items-center rounded-2xl border-[3px] border-ink bg-plum text-3xl">{f.icon}</div>
              <h3 className="mt-4 text-xl font-semibold">{f.title}</h3>
              <p className="mt-1 text-muted-foreground">{f.text}</p>
            </div>
          ))}
        </section>
      </main>
    </div>
  );
}
