import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { AuthLayout, Field } from "@/components/game/AuthLayout";
import { recoverPassword } from "@/services/auth";

export const Route = createFileRoute("/recuperar-senha")({
  head: () => ({
    meta: [
      { title: "Recuperar senha — CODIGMA" },
      { name: "description", content: "Recupere o acesso à sua conta CODIGMA." },
      { property: "og:title", content: "Recuperar senha — CODIGMA" },
      { property: "og:description", content: "Recupere o acesso à sua conta CODIGMA." },
    ],
  }),
  component: RecoverPage,
});

function RecoverPage() {
  const [email, setEmail] = useState("");
  const [error, setError] = useState<string>();
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  return (
    <AuthLayout title="Recuperar senha" subtitle="Acontece com todo dev! Vamos te ajudar." mood={sent ? "feliz" : "pensativo"}>
      {sent ? (
        <div className="space-y-4">
          <p className="rounded-2xl bg-success/15 p-4 font-semibold">
            Se existir uma conta com <b>{email}</b>, enviaremos um link para criar uma nova senha. (Simulação: nenhum e-mail é enviado enquanto o servidor não estiver conectado.)
          </p>
          <Button asChild size="lg" className="w-full">
            <Link to="/entrar">Voltar para o login</Link>
          </Button>
        </div>
      ) : (
        <form
          className="space-y-4"
          noValidate
          onSubmit={async (e) => {
            e.preventDefault();
            const r = z.string().trim().email().safeParse(email);
            if (!r.success) return setError("Digite um e-mail válido.");
            setError(undefined);
            setLoading(true);
            await recoverPassword(r.data);
            setLoading(false);
            setSent(true);
          }}
        >
          <Field label="E-mail da conta" type="email" placeholder="voce@email.com" value={email} onChange={(e) => setEmail(e.target.value)} error={error} />
          <Button type="submit" size="lg" className="w-full" disabled={loading}>
            {loading ? "Enviando..." : "Enviar link de recuperação"}
          </Button>
          <p className="text-center">
            <Link to="/entrar" className="font-semibold text-secondary hover:underline">
              Lembrei a senha
            </Link>
          </p>
        </form>
      )}
    </AuthLayout>
  );
}
