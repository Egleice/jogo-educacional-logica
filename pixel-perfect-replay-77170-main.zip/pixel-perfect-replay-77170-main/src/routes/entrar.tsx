import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { AuthLayout, Field } from "@/components/game/AuthLayout";
import { DEMO_ACCOUNT, login } from "@/services/auth";
import { gameActions } from "@/lib/game/store";

export const Route = createFileRoute("/entrar")({
  head: () => ({
    meta: [
      { title: "Entrar — CODIGMA" },
      { name: "description", content: "Entre na sua conta CODIGMA e continue sua aventura aprendendo Java." },
      { property: "og:title", content: "Entrar — CODIGMA" },
      { property: "og:description", content: "Entre na sua conta CODIGMA e continue sua aventura aprendendo Java." },
    ],
  }),
  component: LoginPage,
});

const schema = z.object({
  email: z.string().trim().email("Digite um e-mail válido."),
  password: z.string().min(6, "A senha tem pelo menos 6 caracteres."),
});

function LoginPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  const submit = async (data = form) => {
    const parsed = schema.safeParse(data);
    if (!parsed.success) {
      setErrors(Object.fromEntries(parsed.error.issues.map((i) => [i.path[0], i.message])));
      return;
    }
    setErrors({});
    setLoading(true);
    try {
      const user = await login(parsed.data);
      gameActions.signIn(user);
      toast.success(`Bem-vindo de volta, ${user.name.split(" ")[0]}!`);
      navigate({ to: "/inicio" });
    } catch (e) {
      setErrors({ form: (e as Error).message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout title="Entrar" subtitle="Que bom te ver de novo! O café está quentinho." mood="animado">
      <form
        className="space-y-4"
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
        noValidate
      >
        <Field label="E-mail" type="email" autoComplete="email" placeholder="voce@email.com" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} error={errors.email} />
        <Field label="Senha" type="password" autoComplete="current-password" placeholder="••••••" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} error={errors.password} />
        {errors.form && <p className="rounded-xl bg-destructive/20 px-3 py-2 font-semibold text-destructive">{errors.form}</p>}
        <div className="flex justify-end">
          <Link to="/recuperar-senha" className="text-sm font-semibold text-secondary hover:underline">
            Esqueci minha senha
          </Link>
        </div>
        <Button type="submit" size="lg" className="w-full" disabled={loading}>
          {loading ? "Entrando..." : "Entrar na aventura"}
        </Button>
        <Button
          type="button"
          variant="outline"
          className="w-full"
          disabled={loading}
          onClick={() => {
            const demo = { email: DEMO_ACCOUNT.email, password: DEMO_ACCOUNT.password };
            setForm(demo);
            submit(demo);
          }}
        >
          Entrar com conta de teste
        </Button>
        <p className="text-center text-muted-foreground">
          Ainda não tem conta?{" "}
          <Link to="/cadastro" className="font-bold text-primary hover:underline">
            Criar conta
          </Link>
        </p>
      </form>
    </AuthLayout>
  );
}
