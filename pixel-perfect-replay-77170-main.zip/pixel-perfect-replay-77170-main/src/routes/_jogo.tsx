import { createFileRoute, Outlet, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { AppShell } from "@/components/game/AppShell";
import { Javi } from "@/components/javi/Javi";
import { useGame } from "@/lib/game/store";

/** Pathless layout for logged-in player screens. Auth is simulated (local), so the guard runs on the client. */
export const Route = createFileRoute("/_jogo")({
  component: GameLayout,
});

function GameLayout() {
  const { ready, user } = useGame();
  const navigate = useNavigate();

  useEffect(() => {
    if (ready && !user) navigate({ to: "/entrar" });
  }, [ready, user, navigate]);

  if (!ready || !user) {
    return (
      <div className="grid min-h-screen place-items-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <Javi mood="pensativo" size={110} />
          <p className="font-display text-lg text-muted-foreground">Preparando o café...</p>
        </div>
      </div>
    );
  }

  return (
    <AppShell>
      <Outlet />
    </AppShell>
  );
}
