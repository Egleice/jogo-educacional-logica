import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { AuthLayout, Field } from "@/components/game/AuthLayout";
import { register } from "@/services/auth";
import { gameActions } from "@/lib/game/store";

export const Route = createFileRoute("/cadastro")({
  head: () => ({
    meta: [
      { title: "Criar conta — CODIGMA" },
      { name: "description", content: "Crie sua conta grátis no CODIGMA e comece a aprender Java jogando." },
      { property: "og:title", content: "Criar conta — CODIGMA" },
      { property: "og:description", content: "Crie sua conta grátis no CODIGMA e comece a aprender Java jogando." },
    ],
  }),
  component: RegisterPage,
});

const schema = z
  .object({
    name: z.string().trim().min(2, "Digite seu nome.").max(40, "Nome muito longo."),
    email: z.string().trim().email("Digite um e-mail válido.").max(255),
    password: z.string().min(6, "A senha precisa de pelo menos 6 caracteres.").max(72),
    confirm: z.string(),
  })
  .refine((d) => d.password === d.confirm, { path: ["confirm"], message: "As senhas não são iguais." });

function RegisterPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "", confirm: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, [k]: e.target.value });

  return (
    <AuthLayout title="Criar conta" subtitle="Monte seu perfil e ganhe 50 moedas de boas-vindas!" mood="comemorando">
      <form
        className="space-y-4"
        noValidate
        onSubmit={async (e) => {
          e.preventDefault();
          const parsed = schema.safeParse(form);
          if (!parsed.success) {
            setErrors(Object.fromEntries(parsed.error.issues.map((i) => [i.path[0], i.message])));
            return;
          }
          setErrors({});
          setLoading(true);
          try {
            const user = await register(parsed.data);
            gameActions.signIn(user);
            toast.success("Conta criada! Bora programar ☕");
            navigate({ to: "/inicio" });
          } catch (err) {
            setErrors({ form: (err as Error).message });
          } finally {
            setLoading(false);
          }
        }}
      >
        <Field label="Nome" autoComplete="name" placeholder="Como o Javi deve te chamar?" value={form.name} onChange={set("name")} error={errors.name} />
        <Field label="E-mail" type="email" autoComplete="email" placeholder="voce@email.com" value={form.email} onChange={set("email")} error={errors.email} />
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Senha" type="password" autoComplete="new-password" value={form.password} onChange={set("password")} error={errors.password} />
          <Field label="Confirmar senha" type="password" autoComplete="new-password" value={form.confirm} onChange={set("confirm")} error={errors.confirm} />
        </div>
        {errors.form && <p className="rounded-xl bg-destructive/20 px-3 py-2 font-semibold text-destructive">{errors.form}</p>}
        <Button type="submit" size="lg" variant="success" className="w-full" disabled={loading}>
          {loading ? "Criando..." : "Criar minha conta"}
        </Button>
        <p className="text-center text-muted-foreground">
          Já tem conta?{" "}
          <Link to="/entrar" className="font-bold text-primary hover:underline">
            Entrar
          </Link>
        </p>
      </form>
    </AuthLayout>
  );
}
