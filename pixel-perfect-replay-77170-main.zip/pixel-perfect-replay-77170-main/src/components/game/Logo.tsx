import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";
import { Javi } from "@/components/javi/Javi";

export function Logo({ className, to = "/", size = "md" }: { className?: string; to?: string; size?: "md" | "lg" }) {
  return (
    <Link to={to} className={cn("group inline-flex items-center gap-2", className)} aria-label="CODIGMA">
      <Javi size={size === "lg" ? 44 : 30} animated={false} className="transition-transform group-hover:animate-wiggle" />
      <span className={cn("font-display font-bold tracking-tight text-foreground", size === "lg" ? "text-4xl" : "text-2xl")}>
        COD<span className="text-primary">I</span>GMA
      </span>
    </Link>
  );
}
