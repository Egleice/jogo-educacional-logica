import { cn } from "@/lib/utils";

const KEYWORDS = new Set(
  "public private static void class int double boolean char String if else for while do switch case break default return new import true false null".split(
    " ",
  ),
);

function highlight(line: string) {
  const parts: { t: string; k: "kw" | "str" | "num" | "com" | "txt" }[] = [];
  const re = /(\/\/.*$)|("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')|(\b\d+(?:\.\d+)?\b)|(\b[A-Za-z_]\w*\b)|([^\w"'/]+|\/)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(line))) {
    if (m[1]) parts.push({ t: m[1], k: "com" });
    else if (m[2]) parts.push({ t: m[2], k: "str" });
    else if (m[3]) parts.push({ t: m[3], k: "num" });
    else if (m[4]) parts.push({ t: m[4], k: KEYWORDS.has(m[4]) ? "kw" : "txt" });
    else parts.push({ t: m[0], k: "txt" });
  }
  return parts.map((p, i) => (
    <span
      key={i}
      className={cn(
        p.k === "kw" && "font-semibold text-primary",
        p.k === "str" && "text-success",
        p.k === "num" && "text-secondary",
        p.k === "com" && "italic text-muted-foreground",
      )}
    >
      {p.t}
    </span>
  ));
}

interface CodeBlockProps {
  code: string | string[];
  className?: string;
  /** 0-based line indexes to mark as wrong / right */
  wrongLines?: number[];
  rightLines?: number[];
  showNumbers?: boolean;
}

export function CodeBlock({ code, className, wrongLines = [], rightLines = [], showNumbers = true }: CodeBlockProps) {
  const lines = Array.isArray(code) ? code : code.split("\n");
  return (
    <pre className={cn("code-block overflow-x-auto p-4 text-sm leading-relaxed", className)}>
      <code>
        {lines.map((l, i) => (
          <div
            key={i}
            className={cn(
              "-mx-2 flex rounded-md px-2",
              wrongLines.includes(i) && "bg-destructive/20 ring-2 ring-destructive",
              rightLines.includes(i) && "bg-success/15 ring-2 ring-success",
            )}
          >
            {showNumbers && <span className="mr-4 w-5 shrink-0 select-none text-right text-muted-foreground/60">{i + 1}</span>}
            <span className="whitespace-pre">{l === "" ? " " : highlight(l)}</span>
          </div>
        ))}
      </code>
    </pre>
  );
}
