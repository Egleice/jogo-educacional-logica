import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { Javi, type JaviMood } from "@/components/javi/Javi";
import { useGame } from "@/lib/game/store";

/** Javi with a cartoon speech bubble. */
export function JaviSays({
  mood = "feliz",
  children,
  size = 110,
  className,
  side = "left",
}: {
  mood?: JaviMood;
  children: ReactNode;
  size?: number;
  className?: string;
  side?: "left" | "right";
}) {
  const { equipped } = useGame();
  return (
    <div className={cn("flex items-end gap-3", side === "right" && "flex-row-reverse", className)}>
      <Javi mood={mood} size={size} equipped={equipped} className="shrink-0" />
      <div
        className={cn(
          "relative mb-6 rounded-3xl border-[3px] border-ink bg-foreground px-4 py-3 font-semibold text-ink shadow-[0_5px_0_0_var(--ink)]",
        )}
      >
        <span
          aria-hidden
          className={cn(
            "absolute bottom-3 h-4 w-4 rotate-45 border-ink bg-foreground",
            side === "left" ? "-left-[10px] border-b-[3px] border-l-[3px]" : "-right-[10px] border-r-[3px] border-t-[3px]",
          )}
        />
        {children}
      </div>
    </div>
  );
}
