import type { ReactNode } from "react";
import { Logo } from "./Logo";
import { Javi, type JaviMood } from "@/components/javi/Javi";

export function AuthLayout({ title, subtitle, mood = "feliz", children }: { title: string; subtitle: string; mood?: JaviMood; children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background px-4 py-8">
      <div className="mx-auto max-w-5xl">
        <Logo />
        <div className="mt-8 grid items-center gap-8 md:grid-cols-[1fr_1.1fr]">
          <div className="hidden flex-col items-center text-center md:flex">
            <Javi mood={mood} size={220} />
            <p className="mt-4 max-w-xs font-display text-xl text-muted-foreground">“Pense, programe, evolua.” — Javi</p>
          </div>
          <div className="game-card p-6 sm:p-8">
            <div className="mb-6 flex items-center gap-3 md:block">
              <Javi mood={mood} size={64} className="md:hidden" animated={false} />
              <div>
                <h1 className="text-3xl font-bold">{title}</h1>
                <p className="mt-1 text-muted-foreground">{subtitle}</p>
              </div>
            </div>
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}

export function Field({ label, error, ...props }: React.InputHTMLAttributes<HTMLInputElement> & { label: string; error?: string }) {
  return (
    <label className="block space-y-1.5">
      <span className="font-display font-semibold">{label}</span>
      <input
        {...props}
        className="h-12 w-full rounded-2xl border-[3px] border-ink bg-ink px-4 text-foreground outline-none transition-shadow placeholder:text-muted-foreground/60 focus:ring-4 focus:ring-ring/40"
      />
      {error && <span className="text-sm font-semibold text-destructive">{error}</span>}
    </label>
  );
}
