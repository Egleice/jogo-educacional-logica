import { useMemo, useState } from "react";
import { ArrowDown, ArrowUp, Check, RotateCcw, ArrowRight, X, Coins, Sparkles, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CodeBlock } from "./CodeBlock";
import { Javi } from "@/components/javi/Javi";
import { useGame } from "@/lib/game/store";
import { cn } from "@/lib/utils";
import { QUESTION_TYPE_LABEL, type ChoiceQuestion, type ErrorQuestion, type OrderQuestion, type Question } from "@/data/questions";
import { checkOrder, shuffleLines } from "@/lib/games/organize";

export interface Reward {
  xp: number;
  coins: number;
}

interface Props {
  question: Question;
  /** Called once per attempt. Return the reward granted (shown in the feedback). */
  onSubmit: (correct: boolean, attempt: number) => Reward;
  onNext: () => void;
  allowRetry?: boolean;
  nextLabel?: string;
  compact?: boolean;
}

type Result =
  | { kind: "choice"; chosen: number; correct: boolean }
  | { kind: "erro"; chosen: number; correct: boolean }
  | { kind: "ordem"; attempt: string[]; marks: boolean[]; correct: boolean };

export function QuestionView({ question, onSubmit, onNext, allowRetry = true, nextLabel = "Continuar", compact }: Props) {
  const [attempt, setAttempt] = useState(1);
  const [result, setResult] = useState<Result | null>(null);
  const [reward, setReward] = useState<Reward>({ xp: 0, coins: 0 });

  const submit = (r: Result) => {
    setResult(r);
    setReward(onSubmit(r.correct, attempt));
  };
  const retry = () => {
    setAttempt((a) => a + 1);
    setResult(null);
  };

  return (
    <div className="space-y-5" key={question.id}>
      <div className="space-y-2">
        <span className="inline-flex items-center rounded-full border-2 border-ink bg-plum px-3 py-1 font-display text-xs font-semibold uppercase tracking-wide text-foreground">
          {QUESTION_TYPE_LABEL[question.type]}
        </span>
        <h2 className={cn("font-display font-semibold leading-snug", compact ? "text-xl" : "text-2xl")}>{question.prompt}</h2>
      </div>

      {question.type === "erro" ? (
        <ErrorInput key={`${question.id}-${attempt}`} q={question} result={result} onSubmit={submit} />
      ) : question.type === "ordem" ? (
        <OrderInput key={`${question.id}-${attempt}`} q={question} result={result} onSubmit={submit} />
      ) : (
        <ChoiceInput key={`${question.id}-${attempt}`} q={question} result={result} onSubmit={submit} />
      )}

      {result && (
        <Feedback
          question={question}
          result={result}
          reward={reward}
          onNext={onNext}
          onRetry={allowRetry && !result.correct ? retry : undefined}
          nextLabel={nextLabel}
        />
      )}
    </div>
  );
}

// ---------------- inputs ----------------

function ChoiceInput({ q, result, onSubmit }: { q: ChoiceQuestion; result: Result | null; onSubmit: (r: Result) => void }) {
  const [sel, setSel] = useState<number | null>(null);
  const done = result !== null;
  const codePreview = q.type === "complete" && q.code ? q.code.replace("___", sel !== null ? q.options[sel]!.text : "____") : q.code;

  return (
    <div className="space-y-4">
      {codePreview && <CodeBlock code={codePreview} />}
      <div className={cn("grid gap-3", q.type === "vf" ? "grid-cols-2" : "sm:grid-cols-2")}>
        {q.options.map((o, i) => {
          const isCorrect = done && i === q.answer;
          const isWrongPick = done && result.kind === "choice" && result.chosen === i && !result.correct;
          return (
            <button
              key={i}
              type="button"
              disabled={done}
              onClick={() => setSel(i)}
              className={cn(
                "press flex min-h-16 items-center gap-3 rounded-2xl border-[3px] border-ink bg-card-raised px-4 py-3 text-left font-semibold shadow-[0_5px_0_0_var(--ink)] transition-colors hover:bg-plum disabled:cursor-default",
                sel === i && !done && "bg-secondary hover:bg-secondary",
                isCorrect && "bg-success text-success-foreground hover:bg-success",
                isWrongPick && "animate-shake bg-destructive text-destructive-foreground hover:bg-destructive",
              )}
            >
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border-2 border-ink bg-ink/30 font-display text-sm">
                {isCorrect ? <Check className="h-4 w-4" /> : isWrongPick ? <X className="h-4 w-4" /> : String.fromCharCode(65 + i)}
              </span>
              <span className={cn("whitespace-pre-line", (q.type !== "vf") && "font-mono text-sm")}>{o.text}</span>
            </button>
          );
        })}
      </div>
      {!done && (
        <Button size="lg" className="w-full sm:w-auto" disabled={sel === null} onClick={() => sel !== null && onSubmit({ kind: "choice", chosen: sel, correct: sel === q.answer })}>
          Verificar resposta
        </Button>
      )}
    </div>
  );
}

function ErrorInput({ q, result, onSubmit }: { q: ErrorQuestion; result: Result | null; onSubmit: (r: Result) => void }) {
  const [sel, setSel] = useState<number | null>(null);
  const done = result !== null;
  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">Toque na linha que contém o erro.</p>
      <div className="code-block space-y-1 p-3 font-mono text-sm">
        {q.lines.map((l, i) => (
          <button
            key={i}
            type="button"
            disabled={done}
            onClick={() => setSel(i)}
            className={cn(
              "flex w-full items-center rounded-lg px-2 py-1.5 text-left transition-colors hover:bg-card",
              sel === i && "bg-secondary/30 ring-2 ring-secondary",
              done && i === q.answer && "bg-destructive/25 ring-2 ring-destructive",
            )}
          >
            <span className="mr-4 w-5 text-right text-muted-foreground/60">{i + 1}</span>
            <span className="whitespace-pre">{l}</span>
          </button>
        ))}
      </div>
      {!done && (
        <Button size="lg" disabled={sel === null} onClick={() => sel !== null && onSubmit({ kind: "erro", chosen: sel, correct: sel === q.answer })}>
          Esta linha tem o erro
        </Button>
      )}
    </div>
  );
}

function OrderInput({ q, result, onSubmit }: { q: OrderQuestion; result: Result | null; onSubmit: (r: Result) => void }) {
  const initial = useMemo(() => shuffleLines(q.lines), [q.lines]);
  const [order, setOrder] = useState(initial);
  const done = result !== null;
  const move = (i: number, d: -1 | 1) => {
    const j = i + d;
    if (j < 0 || j >= order.length) return;
    const next = [...order];
    [next[i], next[j]] = [next[j]!, next[i]!];
    setOrder(next);
  };
  const marks = result?.kind === "ordem" ? result.marks : null;
  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">Use as setas para colocar as linhas na ordem certa.</p>
      <ol className="space-y-2">
        {order.map((l, i) => (
          <li
            key={`${l}-${i}`}
            className={cn(
              "flex items-center gap-2 rounded-xl border-2 border-ink bg-ink p-2 font-mono text-sm transition-colors",
              marks && (marks[i] ? "ring-2 ring-success" : "ring-2 ring-destructive"),
            )}
          >
            <span className="w-5 text-right text-muted-foreground/60">{i + 1}</span>
            <span className="flex-1 overflow-x-auto whitespace-pre">{l}</span>
            {!done && (
              <span className="flex gap-1">
                <Button size="icon" variant="outline" className="h-9 w-9" onClick={() => move(i, -1)} disabled={i === 0} aria-label="Subir linha">
                  <ArrowUp />
                </Button>
                <Button size="icon" variant="outline" className="h-9 w-9" onClick={() => move(i, 1)} disabled={i === order.length - 1} aria-label="Descer linha">
                  <ArrowDown />
                </Button>
              </span>
            )}
          </li>
        ))}
      </ol>
      {!done && (
        <Button
          size="lg"
          onClick={() => {
            const m = checkOrder(order, q.lines);
            onSubmit({ kind: "ordem", attempt: order, marks: m, correct: m.every(Boolean) });
          }}
        >
          Verificar ordem
        </Button>
      )}
    </div>
  );
}

// ---------------- feedback ----------------

function Feedback({
  question,
  result,
  reward,
  onNext,
  onRetry,
  nextLabel,
}: {
  question: Question;
  result: Result;
  reward: Reward;
  onNext: () => void;
  onRetry?: (() => void) | undefined;
  nextLabel: string;
}) {
  const { equipped } = useGame();
  const ok = result.correct;

  return (
    <section
      aria-live="polite"
      className={cn(
        "animate-pop overflow-hidden rounded-3xl border-[3px] border-ink shadow-[0_8px_0_0_var(--ink)]",
        ok ? "bg-success/15" : "bg-primary/10",
      )}
    >
      <div className={cn("flex items-center gap-4 px-5 py-4", ok ? "bg-success text-success-foreground" : "bg-primary text-primary-foreground")}>
        <Javi mood={ok ? "comemorando" : "pensativo"} size={64} equipped={equipped} className={ok ? "animate-bounce-soft" : ""} />
        <div>
          <p className="font-display text-2xl font-bold">{ok ? "Muito bem! Você acertou! 🎉" : "Quase lá! 💡"}</p>
          <p className="font-semibold opacity-90">{ok ? "Javi está orgulhoso de você!" : "Vamos entender o que aconteceu?"}</p>
        </div>
      </div>

      <div className="space-y-4 p-5">
        <FeedbackBody question={question} result={result} />

        <div className="flex flex-wrap items-center gap-2">
          <span className={cn("inline-flex items-center gap-1.5 rounded-full border-2 border-ink px-3 py-1 text-sm font-bold", ok ? "bg-success text-success-foreground" : "bg-plum text-foreground")}>
            <BookOpen className="h-4 w-4" />
            {ok ? "Conceito aprendido:" : "Conceito para revisar:"} {question.concept}
          </span>
          {ok && (reward.xp > 0 || reward.coins > 0) && (
            <span className="inline-flex animate-pop items-center gap-3 rounded-full border-2 border-ink bg-primary px-3 py-1 text-sm font-bold text-primary-foreground">
              <span className="inline-flex items-center gap-1"><Sparkles className="h-4 w-4" /> +{reward.xp} XP</span>
              <span className="inline-flex items-center gap-1"><Coins className="h-4 w-4" /> +{reward.coins}</span>
            </span>
          )}
        </div>

        {!ok && (
          <p className="rounded-2xl bg-card px-4 py-3 font-semibold">
            ☕ Javi diz: “Errar faz parte de programar. Cada erro é um bug a menos no seu caminho!”
          </p>
        )}

        <div className="flex flex-wrap gap-3">
          {onRetry && (
            <Button variant="outline" onClick={onRetry}>
              <RotateCcw /> Tentar novamente
            </Button>
          )}
          <Button variant={ok ? "success" : "default"} onClick={onNext}>
            {nextLabel} <ArrowRight />
          </Button>
        </div>
      </div>
    </section>
  );
}

function FeedbackBody({ question, result }: { question: Question; result: Result }) {
  if (question.type === "erro" && result.kind === "erro") {
    const fixed = [...question.lines];
    fixed[question.answer] = question.fixedLine;
    return (
      <div className="space-y-3">
        {!result.correct && (
          <p>
            Você marcou a <b>linha {result.chosen + 1}</b>. {question.lineNotes[result.chosen] || ""} O erro está na <b>linha {question.answer + 1}</b>.
          </p>
        )}
        <p><b>Por quê?</b> {question.explanation}</p>
        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <p className="mb-1 text-sm font-bold text-destructive">Código com erro</p>
            <CodeBlock code={question.lines} wrongLines={[question.answer]} />
          </div>
          <div>
            <p className="mb-1 text-sm font-bold text-success">Versão corrigida</p>
            <CodeBlock code={fixed.join("\n")} rightLines={[question.answer]} />
          </div>
        </div>
        <p className="text-sm text-muted-foreground">
          <b>O que mudou:</b> a linha {question.answer + 1} passou de <code className="rounded bg-ink px-1">{question.lines[question.answer]!.trim()}</code> para <code className="rounded bg-ink px-1">{question.fixedLine.split("\n")[0]!.trim()}</code>.
        </p>
      </div>
    );
  }

  if (question.type === "ordem" && result.kind === "ordem") {
    const wrong = result.marks.map((m, i) => (m ? -1 : i)).filter((i) => i >= 0);
    return (
      <div className="space-y-3">
        {!result.correct && (
          <p>
            As posições <b>{wrong.map((i) => i + 1).join(", ")}</b> estão fora de ordem.
          </p>
        )}
        <p><b>Sequência correta:</b> {question.explanation}</p>
        <div className="grid gap-3 md:grid-cols-2">
          {!result.correct && (
            <div>
              <p className="mb-1 text-sm font-bold text-destructive">Sua ordem</p>
              <CodeBlock code={result.attempt} wrongLines={wrong} />
            </div>
          )}
          <div>
            <p className="mb-1 text-sm font-bold text-success">Ordem correta</p>
            <CodeBlock code={question.lines} rightLines={result.correct ? [] : wrong} />
          </div>
        </div>
      </div>
    );
  }

  if (result.kind !== "choice" || question.type === "erro" || question.type === "ordem") return null;
  const chosen = question.options[result.chosen]!;
  const right = question.options[question.answer]!;
  return (
    <div className="space-y-3">
      {result.correct ? (
        <p>
          A resposta é <code className="rounded bg-ink px-1.5 py-0.5 font-bold text-success">{right.text}</code>. {right.why}
        </p>
      ) : (
        <>
          <p>
            Você escolheu <code className="rounded bg-ink px-1.5 py-0.5 font-bold text-destructive">{chosen.text}</code>, mas a resposta correta é{" "}
            <code className="rounded bg-ink px-1.5 py-0.5 font-bold text-success">{right.text}</code>.
          </p>
          <p><b>Por que não:</b> {chosen.why}</p>
          <p><b>Raciocínio correto:</b> {right.why}</p>
        </>
      )}
      <p className="text-muted-foreground">{question.explanation}</p>
      {question.type === "complete" && question.code && !result.correct && (
        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <p className="mb-1 text-sm font-bold text-destructive">Seu código</p>
            <CodeBlock code={question.code.replace("___", chosen.text)} wrongLines={lineOf(question.code)} />
          </div>
          <div>
            <p className="mb-1 text-sm font-bold text-success">Versão corrigida</p>
            <CodeBlock code={question.code.replace("___", right.text)} rightLines={lineOf(question.code)} />
          </div>
        </div>
      )}
    </div>
  );
}

function lineOf(code: string): number[] {
  const idx = code.split("\n").findIndex((l) => l.includes("___"));
  return idx >= 0 ? [idx] : [];
}
