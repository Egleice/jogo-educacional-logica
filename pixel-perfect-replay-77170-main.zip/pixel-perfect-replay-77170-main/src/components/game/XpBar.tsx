import { cn } from "@/lib/utils";

export function XpBar({ value, max, className, tone = "primary" }: { value: number; max: number; className?: string; tone?: "primary" | "success" | "destructive" | "secondary" }) {
  const pct = Math.max(0, Math.min(100, (value / Math.max(1, max)) * 100));
  return (
    <div className={cn("h-5 w-full overflow-hidden rounded-full border-[3px] border-ink bg-ink", className)} role="progressbar" aria-valuenow={value} aria-valuemax={max}>
      <div
        className={cn(
          "relative h-full rounded-full transition-[width] duration-700 ease-out",
          tone === "primary" && "bg-primary",
          tone === "success" && "bg-success",
          tone === "destructive" && "bg-destructive",
          tone === "secondary" && "bg-secondary",
        )}
        style={{ width: `${pct}%` }}
      >
        <span className="absolute inset-x-2 top-0.5 h-1 rounded-full bg-foreground/40" />
      </div>
    </div>
  );
}
