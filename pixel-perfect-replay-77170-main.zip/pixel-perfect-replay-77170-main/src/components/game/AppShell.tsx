import type { ReactNode } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { Coins, Flame, LogOut } from "lucide-react";
import { Logo } from "./Logo";
import { gameActions, useGame } from "@/lib/game/store";
import { levelFromXp } from "@/lib/game/progression";
import { cn } from "@/lib/utils";

export const NAV_ITEMS = [
  { to: "/inicio", label: "Início", icon: "🏠" },
  { to: "/aprender", label: "Aprender", icon: "🗺️" },
  { to: "/jogos", label: "Jogos", icon: "🎮" },
  { to: "/ranking", label: "Ranking", icon: "🏆" },
  { to: "/perfil", label: "Perfil", icon: "☕" },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const game = useGame();
  const navigate = useNavigate();
  const lvl = levelFromXp(game.xp);

  return (
    <div className="min-h-screen bg-background pb-28 md:pb-10">
      <header className="sticky top-0 z-30 border-b-[3px] border-ink bg-background/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <Logo to="/inicio" />
          <nav className="mx-auto hidden items-center gap-1 md:flex" aria-label="Navegação principal">
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="group flex items-center gap-2 rounded-2xl border-[3px] border-transparent px-3 py-2 font-display font-semibold text-muted-foreground transition-colors hover:text-foreground"
                activeProps={{ className: "!border-ink bg-card !text-foreground shadow-[0_4px_0_0_var(--ink)]" }}
              >
                <span className="text-xl transition-transform group-hover:scale-125">{item.icon}</span>
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-2 md:ml-0">
            <span className="hidden items-center gap-1 rounded-full border-2 border-ink bg-plum px-3 py-1 font-display text-sm font-bold sm:inline-flex" title="Nível">
              Nv. {lvl.level}
            </span>
            <span className="inline-flex items-center gap-1 rounded-full border-2 border-ink bg-card px-3 py-1 font-display text-sm font-bold text-destructive" title="Dias seguidos">
              <Flame className="h-4 w-4" /> {game.streak}
            </span>
            <Link
              to="/loja"
              className="inline-flex items-center gap-1 rounded-full border-2 border-ink bg-primary px-3 py-1 font-display text-sm font-bold text-primary-foreground transition-transform hover:scale-105"
              title="Moedas — abrir loja"
            >
              <Coins className="h-4 w-4" /> {game.coins}
            </Link>
            <button
              type="button"
              onClick={() => {
                gameActions.signOut();
                navigate({ to: "/" });
              }}
              className="hidden rounded-full p-2 text-muted-foreground transition-colors hover:bg-card hover:text-foreground md:inline-flex"
              aria-label="Sair"
              title="Sair"
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-6 md:py-10">{children}</main>

      {/* mobile bottom nav */}
      <nav
        className="fixed inset-x-3 bottom-3 z-30 flex justify-between rounded-3xl border-[3px] border-ink bg-card px-2 py-2 shadow-[0_6px_0_0_var(--ink)] md:hidden"
        aria-label="Navegação principal"
      >
        {NAV_ITEMS.map((item) => (
          <Link
            key={item.to}
            to={item.to}
            className="flex flex-1 flex-col items-center gap-0.5 rounded-2xl py-1.5 text-[11px] font-bold text-muted-foreground"
            activeProps={{ className: cn("bg-primary !text-primary-foreground") }}
          >
            <span className="text-xl leading-none">{item.icon}</span>
            {item.label}
          </Link>
        ))}
      </nav>
    </div>
  );
}
