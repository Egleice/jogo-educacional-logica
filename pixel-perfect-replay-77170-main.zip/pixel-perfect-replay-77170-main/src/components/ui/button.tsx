import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "press inline-flex items-center justify-center gap-2 whitespace-nowrap font-display font-semibold cursor-pointer select-none border-[3px] border-ink transition-[transform,box-shadow,filter] hover:brightness-105 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-ring/50 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-5 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground shadow-[0_5px_0_0_var(--primary-shade)]",
        success: "bg-success text-success-foreground shadow-[0_5px_0_0_var(--success-shade)]",
        secondary:
          "bg-secondary text-secondary-foreground shadow-[0_5px_0_0_var(--secondary-shade)]",
        plum: "bg-plum text-foreground shadow-[0_5px_0_0_var(--plum-shade)]",
        destructive:
          "bg-destructive text-destructive-foreground shadow-[0_5px_0_0_var(--destructive-shade)]",
        outline: "bg-card text-foreground shadow-[0_5px_0_0_var(--ink)] hover:bg-card-raised",
        ghost:
          "border-transparent bg-transparent text-foreground shadow-none hover:bg-card active:translate-y-0",
        link: "border-transparent bg-transparent text-primary underline-offset-4 shadow-none hover:underline",
      },
      size: {
        default: "h-12 rounded-2xl px-5 text-base",
        sm: "h-10 rounded-xl px-3 text-sm",
        lg: "h-14 rounded-2xl px-8 text-lg",
        icon: "h-11 w-11 rounded-xl",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />
    );
  },
);
Button.displayName = "Button";

export { Button, buttonVariants };
