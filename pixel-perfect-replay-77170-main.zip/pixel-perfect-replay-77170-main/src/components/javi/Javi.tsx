import { cn } from "@/lib/utils";
import type { Equipped } from "@/lib/game/types";

export type JaviMood = "feliz" | "pensativo" | "surpreso" | "triste" | "animado" | "comemorando";

interface JaviProps {
  mood?: JaviMood;
  size?: number;
  equipped?: Equipped;
  className?: string;
  animated?: boolean;
  title?: string;
}

/**
 * Javi — the CODIGMA mascot. A cheerful (male) coffee-cup character.
 * Pure SVG so expressions and accessories can be combined freely.
 */
export function Javi({
  mood = "feliz",
  size = 160,
  equipped = {},
  className,
  animated = true,
  title = "Javi, o mascote do CODIGMA",
}: JaviProps) {
  const armsUp = mood === "comemorando" || mood === "animado";
  return (
    <svg
      viewBox="0 0 200 240"
      width={size}
      height={size * 1.2}
      role="img"
      aria-label={title}
      className={cn(animated && "animate-float", "overflow-visible", className)}
    >
      <title>{title}</title>
      {/* backpack behind body */}
      {equipped.mochila && <Backpack id={equipped.mochila} />}

      {/* steam */}
      {mood !== "triste" && (
        <g stroke="var(--javi-cup)" strokeWidth="5" fill="none" strokeLinecap="round" opacity="0.8">
          <path d="M80 30 q-8 -10 0 -20" className="animate-steam" />
          <path d="M120 30 q8 -10 0 -20" className="animate-steam [animation-delay:0.8s]" />
        </g>
      )}

      {/* legs */}
      <g stroke="var(--ink)" strokeWidth="7" strokeLinecap="round" fill="none">
        <path d="M80 205 L74 228" />
        <path d="M120 205 L126 228" />
      </g>
      <ellipse cx="70" cy="231" rx="14" ry="7" fill="var(--secondary)" stroke="var(--ink)" strokeWidth="3" />
      <ellipse cx="130" cy="231" rx="14" ry="7" fill="var(--secondary)" stroke="var(--ink)" strokeWidth="3" />

      {/* arms */}
      <g stroke="var(--ink)" strokeWidth="7" strokeLinecap="round" fill="none">
        {armsUp ? (
          <>
            <path d="M48 120 Q28 95 30 70" />
            <path d="M152 120 Q172 95 170 70" />
          </>
        ) : mood === "pensativo" ? (
          <>
            <path d="M48 125 Q26 145 36 168" />
            <path d="M152 125 Q170 120 140 108" />
          </>
        ) : mood === "triste" ? (
          <>
            <path d="M48 125 Q34 150 38 175" />
            <path d="M152 125 Q166 150 162 175" />
          </>
        ) : (
          <>
            <path d="M48 125 Q24 140 30 165" />
            <path d="M152 125 Q178 112 182 92" />
          </>
        )}
      </g>
      {/* hands */}
      {armsUp ? (
        <>
          <circle cx="30" cy="66" r="9" fill="var(--javi-cup)" stroke="var(--ink)" strokeWidth="3" />
          <circle cx="170" cy="66" r="9" fill="var(--javi-cup)" stroke="var(--ink)" strokeWidth="3" />
        </>
      ) : mood === "pensativo" ? (
        <>
          <circle cx="36" cy="170" r="9" fill="var(--javi-cup)" stroke="var(--ink)" strokeWidth="3" />
          <circle cx="138" cy="106" r="9" fill="var(--javi-cup)" stroke="var(--ink)" strokeWidth="3" />
        </>
      ) : mood === "triste" ? (
        <>
          <circle cx="38" cy="178" r="9" fill="var(--javi-cup)" stroke="var(--ink)" strokeWidth="3" />
          <circle cx="162" cy="178" r="9" fill="var(--javi-cup)" stroke="var(--ink)" strokeWidth="3" />
        </>
      ) : (
        <>
          <circle cx="30" cy="168" r="9" fill="var(--javi-cup)" stroke="var(--ink)" strokeWidth="3" />
          <circle cx="183" cy="88" r="9" fill="var(--javi-cup)" stroke="var(--ink)" strokeWidth="3" />
        </>
      )}

      {/* cup body (tapered) */}
      <path
        d="M40 62 L160 62 L146 208 Q100 218 54 208 Z"
        fill="var(--javi-cup)"
        stroke="var(--ink)"
        strokeWidth="5"
        strokeLinejoin="round"
      />
      <path d="M140 70 L128 200 Q138 200 146 196 L156 70 Z" fill="var(--javi-cup-shade)" />

      {/* clothes replace sleeve when equipped */}
      {equipped.roupa ? (
        <Clothes id={equipped.roupa} />
      ) : (
        <>
          <path
            d="M47 140 L153 140 L149 178 Q100 186 51 178 Z"
            fill="var(--javi-sleeve)"
            stroke="var(--ink)"
            strokeWidth="4"
            strokeLinejoin="round"
          />
          <text
            x="100"
            y="167"
            textAnchor="middle"
            fontFamily="var(--font-mono)"
            fontWeight="700"
            fontSize="18"
            fill="var(--javi-cup)"
          >
            {"{ }"}
          </text>
        </>
      )}

      {/* lid */}
      <rect x="30" y="46" width="140" height="22" rx="10" fill="var(--javi-lid)" stroke="var(--ink)" strokeWidth="5" />
      <rect x="62" y="34" width="76" height="16" rx="7" fill="var(--javi-lid)" stroke="var(--ink)" strokeWidth="5" />

      {/* face */}
      <Face mood={mood} />

      {/* accessories on top */}
      {equipped.acessorio && <Accessory id={equipped.acessorio} />}
      {equipped.oculos && <Glasses id={equipped.oculos} />}
      {equipped.chapeu && <Hat id={equipped.chapeu} />}
    </svg>
  );
}

function Face({ mood }: { mood: JaviMood }) {
  const eyeY = 98;
  const blush = (
    <>
      <ellipse cx="62" cy="122" rx="9" ry="5" fill="var(--destructive)" opacity="0.35" />
      <ellipse cx="138" cy="122" rx="9" ry="5" fill="var(--destructive)" opacity="0.35" />
    </>
  );
  switch (mood) {
    case "comemorando":
      return (
        <g>
          <path d="M66 100 q10 -14 20 0" stroke="var(--ink)" strokeWidth="5" fill="none" strokeLinecap="round" />
          <path d="M114 100 q10 -14 20 0" stroke="var(--ink)" strokeWidth="5" fill="none" strokeLinecap="round" />
          {blush}
          <path d="M76 114 Q100 146 124 114 Z" fill="var(--ink)" />
          <path d="M88 128 Q100 138 112 128 Q100 124 88 128" fill="var(--destructive)" />
        </g>
      );
    case "animado":
      return (
        <g>
          <Eye cx={76} cy={eyeY} r={11} />
          <Eye cx={124} cy={eyeY} r={11} />
          {blush}
          <path d="M80 116 Q100 138 120 116" stroke="var(--ink)" strokeWidth="5" fill="var(--ink)" strokeLinecap="round" />
        </g>
      );
    case "surpreso":
      return (
        <g>
          <Eye cx={76} cy={eyeY - 2} r={13} />
          <Eye cx={124} cy={eyeY - 2} r={13} />
          <path d="M64 78 q12 -8 24 0" stroke="var(--ink)" strokeWidth="4" fill="none" strokeLinecap="round" />
          <path d="M112 78 q12 -8 24 0" stroke="var(--ink)" strokeWidth="4" fill="none" strokeLinecap="round" />
          <ellipse cx="100" cy="126" rx="9" ry="11" fill="var(--ink)" />
        </g>
      );
    case "triste":
      return (
        <g>
          <Eye cx={76} cy={eyeY + 2} r={10} />
          <Eye cx={124} cy={eyeY + 2} r={10} />
          <path d="M62 84 l22 -6" stroke="var(--ink)" strokeWidth="4" strokeLinecap="round" />
          <path d="M138 84 l-22 -6" stroke="var(--ink)" strokeWidth="4" strokeLinecap="round" />
          <path d="M84 130 Q100 116 116 130" stroke="var(--ink)" strokeWidth="5" fill="none" strokeLinecap="round" />
          <path d="M132 110 q4 10 0 14 q-4 -4 0 -14" fill="var(--secondary)" />
        </g>
      );
    case "pensativo":
      return (
        <g>
          <Eye cx={76} cy={eyeY} r={10} lookX={4} lookY={-4} />
          <Eye cx={124} cy={eyeY} r={10} lookX={4} lookY={-4} />
          <path d="M112 80 q12 -8 24 -2" stroke="var(--ink)" strokeWidth="4" fill="none" strokeLinecap="round" />
          <path d="M86 124 q8 4 14 0 q8 -4 14 2" stroke="var(--ink)" strokeWidth="5" fill="none" strokeLinecap="round" />
        </g>
      );
    default:
      return (
        <g>
          <Eye cx={76} cy={eyeY} r={10} />
          <Eye cx={124} cy={eyeY} r={10} />
          {blush}
          <path d="M82 118 Q100 136 118 118" stroke="var(--ink)" strokeWidth="5" fill="none" strokeLinecap="round" />
        </g>
      );
  }
}

function Eye({ cx, cy, r, lookX = 2, lookY = -2 }: { cx: number; cy: number; r: number; lookX?: number; lookY?: number }) {
  return (
    <g>
      <circle cx={cx} cy={cy} r={r} fill="var(--ink)" />
      <circle cx={cx + lookX} cy={cy + lookY} r={r * 0.38} fill="var(--javi-cup)" />
    </g>
  );
}

function Hat({ id }: { id: string }) {
  switch (id) {
    case "bone-azul":
      return (
        <g>
          <path d="M44 48 Q100 -10 156 48 Z" fill="var(--secondary)" stroke="var(--ink)" strokeWidth="5" strokeLinejoin="round" />
          <path d="M140 46 Q182 44 190 54 Q160 58 140 54 Z" fill="var(--secondary-shade)" stroke="var(--ink)" strokeWidth="4" strokeLinejoin="round" />
          <circle cx="100" cy="18" r="6" fill="var(--primary)" stroke="var(--ink)" strokeWidth="3" />
        </g>
      );
    case "bone-java":
      return (
        <g>
          <path d="M44 48 Q100 -10 156 48 Z" fill="var(--destructive)" stroke="var(--ink)" strokeWidth="5" strokeLinejoin="round" />
          <path d="M60 46 Q18 44 10 54 Q40 58 60 54 Z" fill="var(--destructive-shade)" stroke="var(--ink)" strokeWidth="4" strokeLinejoin="round" />
          <text x="100" y="40" textAnchor="middle" fontFamily="var(--font-display)" fontWeight="700" fontSize="16" fill="var(--javi-cup)">J</text>
        </g>
      );
    case "cartola":
      return (
        <g>
          <rect x="44" y="36" width="112" height="12" rx="6" fill="var(--ink)" />
          <rect x="66" y="-14" width="68" height="54" rx="6" fill="var(--ink)" />
          <rect x="66" y="22" width="68" height="10" fill="var(--destructive)" />
        </g>
      );
    case "coroa":
      return (
        <path
          d="M60 46 L64 6 L82 26 L100 0 L118 26 L136 6 L140 46 Z"
          fill="var(--primary)"
          stroke="var(--ink)"
          strokeWidth="5"
          strokeLinejoin="round"
        />
      );
    case "explorador":
      return (
        <g>
          <ellipse cx="100" cy="44" rx="78" ry="12" fill="var(--javi-lid)" stroke="var(--ink)" strokeWidth="5" />
          <path d="M58 42 Q60 4 100 4 Q140 4 142 42 Z" fill="oklch(0.7 0.08 75)" stroke="var(--ink)" strokeWidth="5" />
          <rect x="60" y="30" width="80" height="8" fill="var(--javi-lid)" />
        </g>
      );
    default:
      return null;
  }
}

function Glasses({ id }: { id: string }) {
  if (id === "oculos-sol") {
    return (
      <g>
        <rect x="56" y="86" width="38" height="24" rx="10" fill="var(--ink)" />
        <rect x="106" y="86" width="38" height="24" rx="10" fill="var(--ink)" />
        <path d="M94 96 L106 96" stroke="var(--ink)" strokeWidth="5" />
        <path d="M62 92 l10 0" stroke="var(--secondary)" strokeWidth="3" strokeLinecap="round" />
      </g>
    );
  }
  if (id === "oculos-pixel") {
    return (
      <g fill="var(--ink)">
        <rect x="54" y="88" width="44" height="8" />
        <rect x="102" y="88" width="44" height="8" />
        <rect x="58" y="96" width="36" height="12" />
        <rect x="106" y="96" width="36" height="12" />
        <rect x="64" y="98" width="6" height="6" fill="var(--javi-cup)" />
        <rect x="112" y="98" width="6" height="6" fill="var(--javi-cup)" />
      </g>
    );
  }
  // nerd round glasses
  return (
    <g fill="none" stroke="var(--ink)" strokeWidth="5">
      <circle cx="76" cy="98" r="18" />
      <circle cx="124" cy="98" r="18" />
      <path d="M94 96 Q100 90 106 96" />
    </g>
  );
}

function Clothes({ id }: { id: string }) {
  const fill =
    id === "moletom-verde" ? "var(--success)" : id === "camisa-amarela" ? "var(--primary)" : "var(--plum)";
  return (
    <g>
      <path
        d="M47 136 L153 136 L148 196 Q100 206 52 196 Z"
        fill={fill}
        stroke="var(--ink)"
        strokeWidth="4"
        strokeLinejoin="round"
      />
      {id === "moletom-verde" && (
        <path d="M80 136 Q100 160 120 136" fill="none" stroke="var(--ink)" strokeWidth="4" />
      )}
      {id === "jaleco-dev" && (
        <>
          <path d="M100 136 L100 200" stroke="var(--ink)" strokeWidth="3" />
          <text x="100" y="172" textAnchor="middle" fontFamily="var(--font-mono)" fontSize="14" fontWeight="700" fill="var(--primary)">
            &lt;/&gt;
          </text>
        </>
      )}
      {id === "camisa-amarela" && (
        <text x="100" y="175" textAnchor="middle" fontFamily="var(--font-display)" fontSize="20" fontWeight="700" fill="var(--ink)">
          ★
        </text>
      )}
    </g>
  );
}

function Backpack({ id }: { id: string }) {
  const fill = id === "mochila-foguete" ? "var(--destructive)" : "var(--success)";
  return (
    <g>
      <rect x="138" y="96" width="44" height="80" rx="16" fill={fill} stroke="var(--ink)" strokeWidth="5" />
      <rect x="146" y="128" width="28" height="22" rx="6" fill="var(--ink)" opacity="0.25" />
      {id === "mochila-foguete" && (
        <path d="M150 176 L160 200 L170 176 Z" fill="var(--primary)" stroke="var(--ink)" strokeWidth="3" />
      )}
    </g>
  );
}

function Accessory({ id }: { id: string }) {
  if (id === "fone") {
    return (
      <g>
        <path d="M40 98 Q40 40 100 40 Q160 40 160 98" fill="none" stroke="var(--ink)" strokeWidth="7" />
        <rect x="30" y="88" width="20" height="32" rx="8" fill="var(--secondary)" stroke="var(--ink)" strokeWidth="4" />
        <rect x="150" y="88" width="20" height="32" rx="8" fill="var(--secondary)" stroke="var(--ink)" strokeWidth="4" />
      </g>
    );
  }
  if (id === "gravata-bug") {
    return (
      <g>
        <path d="M84 136 L100 146 L116 136 L116 156 L100 146 L84 156 Z" fill="var(--destructive)" stroke="var(--ink)" strokeWidth="4" strokeLinejoin="round" />
      </g>
    );
  }
  // medalha
  return (
    <g>
      <path d="M88 132 L100 150 L112 132" fill="none" stroke="var(--secondary)" strokeWidth="5" />
      <circle cx="100" cy="158" r="11" fill="var(--primary)" stroke="var(--ink)" strokeWidth="4" />
    </g>
  );
}
